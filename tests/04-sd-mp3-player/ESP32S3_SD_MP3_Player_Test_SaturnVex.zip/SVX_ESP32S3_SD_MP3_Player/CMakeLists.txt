cmake_minimum_required(VERSION 3.16)
include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(SVX_ESP32S3_SD_MP3_Player)

# ESP-IDF 6.1 / esp_codec_dev 1.5.1 compatibility.
# The managed component is registered as "espressif__esp_codec_dev", not
# "esp_codec_dev". Its audio_codec_ctrl_spi.c uses version macros without
# including esp_idf_version.h. Preinclude that header only for this component.
# Do not modify files under managed_components.
if(TARGET __idf_espressif__esp_codec_dev)
    target_compile_options(__idf_espressif__esp_codec_dev PRIVATE
        "-include" "esp_idf_version.h")
else()
    message(FATAL_ERROR
        "Required target __idf_espressif__esp_codec_dev is missing. Check main/idf_component.yml and run idf.py reconfigure.")
endif()
