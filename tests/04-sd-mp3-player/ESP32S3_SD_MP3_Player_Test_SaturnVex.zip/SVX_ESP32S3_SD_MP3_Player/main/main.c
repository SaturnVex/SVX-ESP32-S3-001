/*
 * SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
 *
 * Project : SVX_ESP32S3_SD_MP3_Player
 * File    : main/main.c
 * Board   : SVX-ESP32-S3-001 (ESP32-S3), ESP-IDF v6.1
 * Purpose : SD-card MP3 player (application revision v7). Recursive folder scan,
 *           MP3 decoding with esp_audio_codec, playback through ES8311 and NS4150.
 *
 * SDMMC 1-bit: CLK GPIO17, CMD GPIO8, D0 GPIO18.
 * ES8311 DAC: I2C SDA GPIO2 / SCL GPIO1, I2S MCLK47 / BCLK14 / WS13 / DOUT21.
 * NS4150 amplifier: hardware enable, no GPIO control.
 * The ES7210 microphone ADC and I2S RX (GPIO48) are not used.
 */
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "esp_vfs_fat.h"
#include "driver/sdmmc_host.h"
#include "sdmmc_cmd.h"
#include "driver/i2c_master.h"
#include "driver/i2s_std.h"
#include "esp_codec_dev.h"
#include "esp_codec_dev_defaults.h"
#include "es8311_codec.h"
#include "esp_audio_simple_dec.h"
#include "esp_audio_simple_dec_default.h"
#include "esp_audio_dec_default.h"

#define TAG                        "SVX_MP3_PLAYER"
#define SD_MOUNT                   "/sdcard"
#define SD_CLK                     GPIO_NUM_17
#define SD_CMD                     GPIO_NUM_8
#define SD_D0                      GPIO_NUM_18
#define I2C_SCL                    GPIO_NUM_1
#define I2C_SDA                    GPIO_NUM_2
#define I2S_MCLK                   GPIO_NUM_47
#define I2S_BCLK                   GPIO_NUM_14
#define I2S_WS                     GPIO_NUM_13
#define I2S_DOUT                   GPIO_NUM_21
#define I2S_DEFAULT_RATE           44100
#define SPEAKER_VOLUME             75  /* 0-100; start low; increase carefully */
#define MAX_SCAN_DEPTH             24
#define MAX_AUDIO_PATH_BYTES        1024
#define MP3_READ_CHUNK             2048
#define PCM_DECODE_BYTES           16384
#define PCM32_FRAMES               1152
#define SONG_GAP_MS                150
#define REPEAT_PLAYLIST            1

static i2c_master_bus_handle_t s_bus;
static i2s_chan_handle_t s_tx;
static esp_codec_dev_handle_t s_dac;
static sdmmc_card_t *s_card;
static bool s_dac_open;
static uint32_t s_current_rate = I2S_DEFAULT_RATE;
static uint32_t s_total_played;
static uint32_t s_total_failed;
static uint32_t s_total_folders;
static uint8_t s_mp3_data[MP3_READ_CHUNK];
static uint8_t s_decoded[PCM_DECODE_BYTES];
static int32_t s_pcm32[PCM32_FRAMES * 2];

static bool is_mp3(const char *filename)
{
    const char *dot = strrchr(filename, '.');
    return dot && !strcasecmp(dot, ".mp3") && filename[0] != '.';
}

/* Directory traversal is lazy: a list exists only for the current folder.
 * All folders below /sdcard are explored, instead of only /sdcard and /music.
 * There is no fixed playlist length limit.
 */
static int name_compare(const void *a, const void *b)
{
    const char *x = *(const char *const *)a;
    const char *y = *(const char *const *)b;
    int cmp = strcasecmp(x, y);
    return cmp ? cmp : strcmp(x, y);
}

static bool is_visible_entry(const char *name)
{
    return name && name[0] != '\0' && name[0] != '.';
}

static char *make_child_path(const char *parent, const char *name)
{
    size_t n1 = strlen(parent), n2 = strlen(name);
    if (n1 + n2 + 2 > MAX_AUDIO_PATH_BYTES) {
        ESP_LOGW(TAG, "Path too long, skip: %s/%s", parent, name);
        return NULL;
    }
    char *path = malloc(n1 + n2 + 2);
    if (path) snprintf(path, n1 + n2 + 2, "%s/%s", parent, name);
    return path;
}

static void release_names(char **names, size_t count)
{
    for (size_t i = 0; i < count; ++i) free(names[i]);
    free(names);
}

/* Get and sort just the child names in one directory. d_type is not
 * portable on FATFS, so stat() decides whether each entry is a folder/file.
 * Returning false means this directory could not be fully enumerated.
 */
static bool read_sorted_names(const char *folder, char ***out_names, size_t *out_count)
{
    *out_names = NULL;
    *out_count = 0;
    DIR *dir = opendir(folder);
    if (!dir) {
        ESP_LOGW(TAG, "Cannot open folder %s (errno=%d)", folder, errno);
        return false;
    }
    char **names = NULL;
    size_t count = 0, capacity = 0;
    bool complete = true;
    struct dirent *ent;
    errno = 0;
    while ((ent = readdir(dir)) != NULL) {
        if (!is_visible_entry(ent->d_name)) continue;
        if (count == capacity) {
            size_t next = capacity ? capacity * 2 : 32;
            if (next < capacity || next > SIZE_MAX / sizeof(char *)) {
                complete = false;
                break;
            }
            char **tmp = realloc(names, next * sizeof(char *));
            if (!tmp) { complete = false; break; }
            names = tmp;
            capacity = next;
        }
        names[count] = strdup(ent->d_name);
        if (!names[count]) { complete = false; break; }
        count++;
        errno = 0;
    }
    int read_errno = errno;
    closedir(dir);
    if (read_errno) complete = false;
    if (!complete) {
        ESP_LOGE(TAG, "Folder scan incomplete: %s (errno=%d, entries=%u)",
                 folder, read_errno, (unsigned)count);
    }
    qsort(names, count, sizeof(*names), name_compare);
    *out_names = names;
    *out_count = count;
    return complete;
}

static esp_err_t mount_sd(void)
{
    sdmmc_host_t host = SDMMC_HOST_DEFAULT();
    host.slot = SDMMC_HOST_SLOT_1;
    host.max_freq_khz = 10000; /* Tested SD project: SDMMC 1-bit, 10 MHz */
    sdmmc_slot_config_t slot = SDMMC_SLOT_CONFIG_DEFAULT();
    slot.width = 1;
    slot.clk = SD_CLK;
    slot.cmd = SD_CMD;
    slot.d0 = SD_D0;
    slot.flags |= SDMMC_SLOT_FLAG_INTERNAL_PULLUP;
    esp_vfs_fat_sdmmc_mount_config_t cfg = {
        .format_if_mount_failed = false,
        .max_files = 5,
        .allocation_unit_size = 16 * 1024,
    };
    esp_err_t rc = esp_vfs_fat_sdmmc_mount(SD_MOUNT, &host, &slot, &cfg, &s_card);
    if (rc == ESP_OK) {
        ESP_LOGI(TAG, "SD mounted read-only in application logic (no writes), SDMMC 1-bit 10MHz");
        sdmmc_card_print_info(stdout, s_card);
    }
    return rc;
}

static esp_err_t init_audio_hardware(void)
{
    i2c_master_bus_config_t bc = {
        .i2c_port = I2C_NUM_0,
        .sda_io_num = I2C_SDA,
        .scl_io_num = I2C_SCL,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    ESP_RETURN_ON_ERROR(i2c_new_master_bus(&bc, &s_bus), TAG, "I2C");

    i2s_chan_config_t ch = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    ch.dma_desc_num = 8;
    ch.dma_frame_num = 256;
    ESP_RETURN_ON_ERROR(i2s_new_channel(&ch, &s_tx, NULL), TAG, "I2S TX only");
    i2s_std_config_t std = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(I2S_DEFAULT_RATE),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT,
                                                        I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_MCLK,
            .bclk = I2S_BCLK,
            .ws = I2S_WS,
            .dout = I2S_DOUT,
            .din = I2S_GPIO_UNUSED,
        },
    };
    ESP_RETURN_ON_ERROR(i2s_channel_init_std_mode(s_tx, &std), TAG, "I2S init");

    audio_codec_i2c_cfg_t ci = {
        .addr = ES8311_CODEC_DEFAULT_ADDR,
        .bus_handle = s_bus,
    };
    const audio_codec_ctrl_if_t *ctrl = audio_codec_new_i2c_ctrl(&ci);
    const audio_codec_gpio_if_t *gpio = audio_codec_new_gpio();
    audio_codec_i2s_cfg_t di = {
        .port = I2S_NUM_0,
        .rx_handle = NULL,
        .tx_handle = s_tx,
    };
    const audio_codec_data_if_t *data = audio_codec_new_i2s_data(&di);
    if (!ctrl || !gpio || !data) return ESP_ERR_NO_MEM;
    es8311_codec_cfg_t chip = {
        .ctrl_if = ctrl,
        .gpio_if = gpio,
        .codec_mode = ESP_CODEC_DEV_WORK_MODE_DAC,
        .pa_pin = -1,
        .use_mclk = true,
        .master_mode = false,
    };
    const audio_codec_if_t *codec = es8311_codec_new(&chip);
    if (!codec) return ESP_FAIL;
    esp_codec_dev_cfg_t dc = {
        .codec_if = codec,
        .data_if = data,
        .dev_type = ESP_CODEC_DEV_TYPE_OUT,
    };
    s_dac = esp_codec_dev_new(&dc);
    return s_dac ? ESP_OK : ESP_ERR_NO_MEM;
}

static void stop_speaker(void)
{
    if (s_dac_open) {
        (void)esp_codec_dev_set_out_mute(s_dac, true);
        (void)esp_codec_dev_close(s_dac);
        s_dac_open = false;
    }
}

/* Reconfigure sample rate for each track: MP3 music commonly uses 44.1k/48k. */
static bool start_speaker(uint32_t rate)
{
    if (rate < 8000 || rate > 48000) {
        ESP_LOGE(TAG, "Unsupported sample rate: %lu Hz", (unsigned long)rate);
        return false;
    }
    /* A new MP3 file does not require restarting the codec if its rate
     * matches the active I2S stream. Reopening on every track caused the
     * esp_codec_dev adapter to call i2s_channel_disable on a disabled channel.
     * Keeping TX open also reduces gaps and avoids codec power cycling. */
    if (s_dac_open && rate == s_current_rate) {
        return true;
    }
    /* A real format change does require the codec to be closed first. */
    stop_speaker();
    if (rate != s_current_rate) {
        i2s_std_clk_config_t clk = I2S_STD_CLK_DEFAULT_CONFIG(rate);
        esp_err_t err = i2s_channel_reconfig_std_clock(s_tx, &clk);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "I2S rate %lu failed: %s", (unsigned long)rate, esp_err_to_name(err));
            return false;
        }
        s_current_rate = rate;
    }
    esp_codec_dev_sample_info_t fs = {
        .sample_rate = (int)rate,
        .channel = 2,
        .bits_per_sample = 32,
    };
    if (esp_codec_dev_open(s_dac, &fs) != 0) {
        ESP_LOGE(TAG, "ES8311 open at %lu Hz failed", (unsigned long)rate);
        return false;
    }
    s_dac_open = true;
    if (esp_codec_dev_set_out_vol(s_dac, SPEAKER_VOLUME) != 0 ||
        esp_codec_dev_set_out_mute(s_dac, false) != 0) {
        ESP_LOGE(TAG, "ES8311 volume/unmute failed");
        stop_speaker();
        return false;
    }
    ESP_LOGI(TAG, "DAC active: %lu Hz, 32-bit stereo I2S, volume=%d",
             (unsigned long)rate, SPEAKER_VOLUME);
    return true;
}

/* Original MP3 PCM is 16-bit interleaved. Physical device uses one speaker:
 * combine L/R to mono, duplicate onto both 32-bit I2S slots (PCM16 << 16).
 * No microphone, no AEC, no AGC, no dynamic gain, no hard clipping.
 */
static bool play_pcm16(const uint8_t *buffer, size_t bytes, int channels)
{
    if (channels != 1 && channels != 2) return false;
    const int16_t *pcm = (const int16_t *)buffer;
    size_t frames = bytes / (sizeof(int16_t) * (size_t)channels);
    size_t offset = 0;
    while (offset < frames) {
        size_t count = frames - offset;
        if (count > PCM32_FRAMES) count = PCM32_FRAMES;
        for (size_t i = 0; i < count; i++) {
            int32_t x;
            if (channels == 1) x = pcm[offset + i];
            else {
                size_t pos = 2 * (offset + i);
                x = ((int32_t)pcm[pos] + (int32_t)pcm[pos + 1]) / 2;
            }
            int32_t slot = x * 65536; /* No signed left shift of negative values. */
            s_pcm32[i * 2] = slot;
            s_pcm32[i * 2 + 1] = slot;
        }
        if (esp_codec_dev_write(s_dac, s_pcm32, count * 2 * sizeof(int32_t)) != 0) {
            ESP_LOGE(TAG, "ES8311 write error");
            return false;
        }
        offset += count;
    }
    return true;
}

static bool play_mp3_file(const char *path)
{
    ESP_LOGI(TAG, "PLAY: %s", path);
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        ESP_LOGE(TAG, "Open failed errno=%d", errno);
        return false;
    }
    esp_audio_simple_dec_cfg_t cfg = {
        .dec_type = ESP_AUDIO_SIMPLE_DEC_TYPE_MP3,
        .use_frame_dec = false,
    };
    esp_audio_simple_dec_handle_t decoder = NULL;
    esp_audio_err_t er = esp_audio_simple_dec_open(&cfg, &decoder);
    if (er != ESP_AUDIO_ERR_OK || !decoder) {
        ESP_LOGE(TAG, "MP3 decoder open failed: %d", (int)er);
        fclose(fp);
        return false;
    }
    bool ok = true;
    bool started = false;
    uint32_t track_rate = 0;
    size_t total_pcm = 0;
    for (;;) {
        size_t n = fread(s_mp3_data, 1, sizeof(s_mp3_data), fp);
        bool eof = (n < sizeof(s_mp3_data));
        if (ferror(fp)) { ok = false; break; }
        if (n == 0 && !eof) break;
        esp_audio_simple_dec_raw_t raw = {
            .buffer = s_mp3_data,
            .len = (uint32_t)n,
            .eos = eof,
        };
        unsigned stall = 0;
        unsigned iterations = 0;
        do {
            if (++iterations > 4096) {
                ESP_LOGE(TAG, "MP3 decoder iteration guard");
                ok = false;
                break;
            }
            esp_audio_simple_dec_out_t out = {
                .buffer = s_decoded,
                .len = sizeof(s_decoded),
            };
            er = esp_audio_simple_dec_process(decoder, &raw, &out);
            if (er != ESP_AUDIO_ERR_OK) {
                ESP_LOGE(TAG, "MP3 decode failed: %d", (int)er);
                ok = false;
                break;
            }
            if (out.decoded_size > 0) {
                esp_audio_simple_dec_info_t info = {0};
                if (esp_audio_simple_dec_get_info(decoder, &info) != ESP_AUDIO_ERR_OK ||
                    info.bits_per_sample != 16 || (info.channel != 1 && info.channel != 2)) {
                    ESP_LOGE(TAG, "Unsupported decoded MP3 PCM format");
                    ok = false;
                    break;
                }
                if (!started) {
                    if (!start_speaker(info.sample_rate)) {
                        ok = false;
                        break;
                    }
                    track_rate = info.sample_rate;
                    started = true;
                    ESP_LOGI(TAG, "MP3 format %lu Hz %u-bit %u-ch",
                             (unsigned long)info.sample_rate,
                             (unsigned)info.bits_per_sample, (unsigned)info.channel);
                } else if (info.sample_rate != track_rate) {
                    ESP_LOGE(TAG, "Sample rate changed within MP3; unsupported");
                    ok = false;
                    break;
                }
                if (!play_pcm16(out.buffer, out.decoded_size, info.channel)) {
                    ok = false;
                    break;
                }
                total_pcm += out.decoded_size;
            }
            /* Codec parser follows the documented consumed-byte contract.
             * Never overwrite input bytes until raw.len is fully consumed. */
            if (raw.consumed > raw.len) { ok = false; break; }
            if (raw.consumed == 0 && out.decoded_size == 0) {
                if (++stall > 3) { ESP_LOGE(TAG, "MP3 decoder no progress"); ok = false; break; }
            } else stall = 0;
            raw.buffer += raw.consumed;
            raw.len -= raw.consumed;
        } while (ok && raw.len > 0);
        if (!ok || eof) break;
    }
    if (!started) {
        ESP_LOGE(TAG, "No playable MP3 frames in %s", path);
        ok = false;
    }
    /* Drain the last PCM samples before beginning the next file.
     * Keep DAC and I2S running across tracks of the same sample rate.
     * This prevents repeated codec open/close and removes spurious
     * i2s_channel_disable errors during normal track changes.
     * It is not a sample-exact gapless player. */
    if (started) vTaskDelay(pdMS_TO_TICKS(100));
    esp_audio_simple_dec_close(decoder);
    fclose(fp);
    ESP_LOGI(TAG, "%s: %s, decoded PCM=%lu bytes", ok ? "DONE" : "SKIP",
             path, (unsigned long)total_pcm);
    return ok;
}

/* Alphabetical depth-first traversal. No global playlist retained.
 * Folder names and MP3 names are sorted independently at each level by
 * case-insensitive filename. Playback returns to the current directory
 * after each subdirectory has completed.
 */
static void play_tree(const char *folder, unsigned depth)
{
    if (depth >= MAX_SCAN_DEPTH) {
        ESP_LOGW(TAG, "Folder nesting limit %u reached: %s", MAX_SCAN_DEPTH, folder);
        return;
    }

    char **names = NULL;
    size_t count = 0;
    bool complete = read_sorted_names(folder, &names, &count);
    if (!complete && count == 0) {
        free(names);
        return;
    }
    s_total_folders++;
    ESP_LOGI(TAG, "SCAN depth=%u entries=%u folder=%s", depth, (unsigned)count, folder);
    for (size_t i = 0; i < count; ++i) {
        char *path = make_child_path(folder, names[i]);
        if (!path) continue;
        struct stat st;
        if (stat(path, &st) == 0) {
            if (S_ISDIR(st.st_mode)) {
                play_tree(path, depth + 1);
            } else if (S_ISREG(st.st_mode) && is_mp3(names[i])) {
                ESP_LOGI(TAG, "TRACK %lu: %s", (unsigned long)(s_total_played + s_total_failed + 1), path);
                if (play_mp3_file(path)) s_total_played++;
                else s_total_failed++;
                vTaskDelay(pdMS_TO_TICKS(SONG_GAP_MS));
            }
        } else {
            ESP_LOGW(TAG, "stat failed: %s (errno=%d)", path, errno);
        }
        free(path);
        /* Keep watchdog-friendly CPU access between tracks/folders. */
        if ((i & 31U) == 31U) vTaskDelay(pdMS_TO_TICKS(1));
    }
    release_names(names, count);
}

static void player_task(void *unused)
{
    (void)unused;
    ESP_LOGI(TAG, "SATURNVEX MP3 PLAYER — recursive SD folders -> MP3 -> ES8311 -> NS4150");
    ESP_LOGI(TAG, "No MIC ES7210; no karaoke monitoring or AEC");
    esp_err_t rc = init_audio_hardware();
    if (rc != ESP_OK) {
        ESP_LOGE(TAG, "Codec/I2S init failed: %s", esp_err_to_name(rc));
        goto idle;
    }
    rc = mount_sd();
    if (rc != ESP_OK) {
        ESP_LOGE(TAG, "SD mount failed: %s; check FAT32 and GPIO17/8/18",
                 esp_err_to_name(rc));
        goto idle;
    }
    /* esp_audio_codec has TWO independent registration layers:
     * 1. Core audio decoders (MP3 backend).
     * 2. Simple-decoder parsers/adapters (stream from arbitrary MP3 bytes).
     * Registering only layer 2 causes "Decoder MP3 not registered" (-7).
     */
    esp_audio_err_t dec_err = esp_audio_dec_register_default();
    if (dec_err != ESP_AUDIO_ERR_OK) {
        ESP_LOGE(TAG, "Core audio decoder registration failed: %d", (int)dec_err);
        goto idle;
    }
    dec_err = esp_audio_simple_dec_register_default();
    if (dec_err != ESP_AUDIO_ERR_OK) {
        ESP_LOGE(TAG, "Simple decoder registration failed: %d", (int)dec_err);
        esp_audio_dec_unregister_default();
        goto idle;
    }
    dec_err = esp_audio_simple_check_audio_type(ESP_AUDIO_SIMPLE_DEC_TYPE_MP3);
    if (dec_err != ESP_AUDIO_ERR_OK) {
        ESP_LOGE(TAG, "MP3 decoder is unavailable: %d. Check CONFIG_AUDIO_DECODER_MP3_SUPPORT in sdkconfig", (int)dec_err);
        esp_audio_simple_dec_unregister_default();
        esp_audio_dec_unregister_default();
        goto idle;
    }
    ESP_LOGI(TAG, "MP3 core decoder + simple decoder registered successfully");
    do {
        s_total_played = 0;
        s_total_failed = 0;
        s_total_folders = 0;
        ESP_LOGI(TAG, "Starting recursive SD scan from %s", SD_MOUNT);
        play_tree(SD_MOUNT, 0);
        ESP_LOGI(TAG, "PASS END: folders=%lu played=%lu failed=%lu",
                 (unsigned long)s_total_folders,
                 (unsigned long)s_total_played,
                 (unsigned long)s_total_failed);
        if (s_total_played + s_total_failed == 0) {
            ESP_LOGW(TAG, "No MP3 found in any visible SD folder. Card remains mounted.");
            break;
        }
        vTaskDelay(pdMS_TO_TICKS(SONG_GAP_MS));
    } while (REPEAT_PLAYLIST);
    esp_audio_simple_dec_unregister_default();
    esp_audio_dec_unregister_default();
idle:
    stop_speaker();
    ESP_LOGW(TAG, "Player idle. Reset board after inserting/changing SD card.");
    for (;;) vTaskDelay(pdMS_TO_TICKS(3000));
}

void app_main(void)
{
    BaseType_t result = xTaskCreatePinnedToCore(player_task, "mp3_player", 16384,
                                                 NULL, 5, NULL, 1);
    if (result != pdPASS) ESP_LOGE(TAG, "Failed to create MP3 player task");
}
