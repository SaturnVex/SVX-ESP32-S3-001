# SD Card MP3 Player

**Project:** `SVX_ESP32S3_SD_MP3_Player` · **Board:** `SVX-ESP32-S3-001` · **MCU:** ESP32-S3 · **Framework:** ESP-IDF v6.1

Autonomous MP3 player (application revision v7). The firmware mounts the microSD card, scans all folders recursively, decodes each `.mp3` file with Espressif `esp_audio_codec` and plays it through the ES8311 DAC and the on-board NS4150 speaker amplifier. The playlist repeats after the last track. The microphone path is not used.

## Connections

| Signal | ESP32-S3 |
|---|---|
| SDMMC CLK / CMD / D0 | GPIO17 / GPIO8 / GPIO18 (1-bit, 10 MHz) |
| Codec I²C SCL / SDA | GPIO1 / GPIO2 |
| I2S MCLK / BCLK / WS / DOUT | GPIO47 / GPIO14 / GPIO13 / GPIO21 |
| NS4150 amplifier | Enabled by board hardware |

## Features

- Recursive folder scan (up to 24 levels), case-insensitive name order, depth-first; hidden and non-MP3 files are skipped.
- Per-track sample rate 8 – 48 kHz; the DAC stays open between tracks with the same rate.
- Output volume 75/100 (`SPEAKER_VOLUME` in `main/main.c`). The card is only read, never written.

## Build and flash

Open this folder (the one containing `CMakeLists.txt`) in VS Code with the ESP-IDF extension, then open an **ESP-IDF v6.1 terminal** and run:

```powershell
Remove-Item Env:IDF_TARGET -ErrorAction SilentlyContinue
idf.py set-target esp32s3
idf.py build
idf.py -p COM_PORT -b 115200 flash monitor
```

Replace `COM_PORT` with the native USB Serial/JTAG port of the board (for example `COM10`). Exit the monitor with `Ctrl+]`. The first build needs Internet access: the ESP-IDF Component Manager downloads `esp_codec_dev` 1.5.1 and `esp_audio_codec` 2.6.2.

## Expected result

Insert a FAT32 card containing MP3 files and reset the board. The log lists the discovered tracks and prints `PLAY:` for each file while audio is heard from the speaker.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex source and project files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
