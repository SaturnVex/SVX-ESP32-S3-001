# BLE Multi-Client Test

**Project:** `SVX_ESP32S3_BLE_MultiClient` · **Board:** `SVX-ESP32-S3-001` · **MCU:** ESP32-S3 · **Framework:** ESP-IDF v6.1

NimBLE Bluetooth LE peripheral advertising as **`SaturnVex-S3`**. It exposes a UART-style GATT service (Nordic UART Service UUIDs), accepts up to **five concurrent connections**, answers text commands and streams simulated JSON telemetry to every subscribed client. No external GPIO is used.

## GATT service

| Attribute | UUID | Properties |
|---|---|---|
| Service | `6e400001-b5a3-f393-e0a9-e50e24dcca9e` | Primary |
| RX (phone → board) | `6e400002-b5a3-f393-e0a9-e50e24dcca9e` | Write / Write without response |
| TX (board → phone) | `6e400003-b5a3-f393-e0a9-e50e24dcca9e` | Read / Notify |

## Commands (UTF-8 text written to RX)

| Command | Response on TX |
|---|---|
| `PING` | `{"reply":"PONG"}` |
| `STATUS` | Connection, streaming and period state |
| `START` / `STOP` | Start / stop periodic telemetry (global for all clients) |
| `SET_RATE=500` | Telemetry period in ms, 100 – 10000 (global) |

Telemetry values (temperature, humidity, battery) are synthetic test data, not sensor readings. Request an MTU of 185 or more in the phone app before enabling notifications so that complete JSON packets fit.

## Build and flash

Open this folder (the one containing `CMakeLists.txt`) in VS Code with the ESP-IDF extension, then open an **ESP-IDF v6.1 terminal** and run:

```powershell
Remove-Item Env:IDF_TARGET -ErrorAction SilentlyContinue
idf.py set-target esp32s3
idf.py build
idf.py -p COM_PORT -b 115200 flash monitor
```

Replace `COM_PORT` with the native USB Serial/JTAG port of the board (for example `COM10`). Exit the monitor with `Ctrl+]`. `sdkconfig` already sets `CONFIG_BT_NIMBLE_MAX_CONNECTIONS=5`; if you regenerate it, check this value again.

Keep the project in a short path (for example `D:\ESP32\SVX_ESP32S3_BLE_MultiClient`) to avoid Windows path-length errors during the mbedTLS build.

## Test procedure

1. Install **nRF Connect for Mobile** on one or more phones and enable Bluetooth.
2. Scan for `SaturnVex-S3`, connect, discover services and enable notifications on TX.
3. Write `PING`, `STATUS`, `START`, `SET_RATE=500` and `STOP` to RX and check the responses.
4. Connect further phones (up to five); each subscribed phone receives telemetry. Disconnecting one phone must not affect the others, and the board keeps advertising while slots are free.

Full procedure and acceptance criteria: see the PDF test guide.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex source and project files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
