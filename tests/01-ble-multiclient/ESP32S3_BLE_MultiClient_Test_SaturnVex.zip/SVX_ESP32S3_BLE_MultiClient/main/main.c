/*
 * SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
 *
 * Project : SVX_ESP32S3_BLE_MultiClient
 * File    : main/main.c
 * Board   : SVX-ESP32-S3-001 (ESP32-S3), ESP-IDF v6.1
 * Purpose : BLE multi-client test. NimBLE GATT peripheral "SaturnVex-S3" with a
 *           UART-style service (Nordic UART Service compatible UUIDs), up to five
 *           concurrent connections, text commands and simulated JSON telemetry.
 *
 * No external GPIO is used; programming and logs via native USB Serial/JTAG.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "nvs_flash.h"
#include "host/ble_hs.h"
#include "host/util/util.h" /* ble_hs_util_ensure_addr declaration */
#include "host/ble_uuid.h"
#include "host/ble_gap.h"
#include "host/ble_gatt.h"
#include "host/ble_att.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "os/os_mbuf.h"

#define DEVICE_NAME "SaturnVex-S3"
#define INVALID_CONN_HANDLE 0xFFFF
#define DEFAULT_PERIOD_MS 1000U
#define MIN_PERIOD_MS 100U
#define MAX_PERIOD_MS 10000U
#define CMD_MAX_LEN 95U
#define MAX_CLIENTS 5U

static const char *TAG = "SVX_BLE";
static uint8_t s_addr_type;
typedef struct {
    uint16_t handle;
    bool subscribed;
} ble_client_t;

static ble_client_t s_clients[MAX_CLIENTS];
static uint8_t s_client_count = 0;

static int client_index(uint16_t handle)
{
    for (unsigned i = 0; i < MAX_CLIENTS; ++i) {
        if (s_clients[i].handle == handle) return (int)i;
    }
    return -1;
}

static bool client_add(uint16_t handle)
{
    if (client_index(handle) >= 0) return true;
    for (unsigned i = 0; i < MAX_CLIENTS; ++i) {
        if (s_clients[i].handle == INVALID_CONN_HANDLE) {
            s_clients[i].handle = handle;
            s_clients[i].subscribed = false;
            ++s_client_count;
            return true;
        }
    }
    return false;
}

static void client_remove(uint16_t handle)
{
    int idx = client_index(handle);
    if (idx < 0) return;
    s_clients[idx].handle = INVALID_CONN_HANDLE;
    s_clients[idx].subscribed = false;
    if (s_client_count) --s_client_count;
}

static bool any_subscribed(void)
{
    for (unsigned i = 0; i < MAX_CLIENTS; ++i)
        if (s_clients[i].handle != INVALID_CONN_HANDLE && s_clients[i].subscribed) return true;
    return false;
}
static uint16_t s_tx_val_handle;
static bool s_streaming = true;
static uint32_t s_period_ms = DEFAULT_PERIOD_MS;
static uint32_t s_sample_id = 0;
static char s_last_tx[160] = "{\"ready\":true}";

/* 128-bit custom UUID: 6e400001/2/3-b5a3-f393-e0a9-e50e24dcca9e (UART-like).
 * UUID values are IDs for this test, not claims of Nordic UART Service certification.
 */
static const ble_uuid128_t s_service_uuid = BLE_UUID128_INIT(
    0x9e,0xca,0xdc,0x24,0x0e,0xe5,0xa9,0xe0,0x93,0xf3,0xa3,0xb5,0x01,0x00,0x40,0x6e);
static const ble_uuid128_t s_rx_uuid = BLE_UUID128_INIT(
    0x9e,0xca,0xdc,0x24,0x0e,0xe5,0xa9,0xe0,0x93,0xf3,0xa3,0xb5,0x02,0x00,0x40,0x6e);
static const ble_uuid128_t s_tx_uuid = BLE_UUID128_INIT(
    0x9e,0xca,0xdc,0x24,0x0e,0xe5,0xa9,0xe0,0x93,0xf3,0xa3,0xb5,0x03,0x00,0x40,0x6e);

static void send_to(uint16_t handle, const char *msg)
{
    snprintf(s_last_tx, sizeof(s_last_tx), "%s", msg);
    ESP_LOGI(TAG, "TX [%u]: %s", handle, msg);
    int idx = client_index(handle);
    if (idx < 0 || !s_clients[idx].subscribed) return;
    struct os_mbuf *om = ble_hs_mbuf_from_flat(msg, strlen(msg));
    if (!om) { ESP_LOGW(TAG, "No mbuf available"); return; }
    int rc = ble_gatts_notify_custom(handle, s_tx_val_handle, om);
    if (rc) ESP_LOGW(TAG, "Notify failed [%u]: %d", handle, rc);
}

static void send_all(const char *msg)
{
    for (unsigned i = 0; i < MAX_CLIENTS; ++i) {
        if (s_clients[i].handle != INVALID_CONN_HANDLE && s_clients[i].subscribed)
            send_to(s_clients[i].handle, msg);
    }
}

static void handle_command(uint16_t handle, const char *cmd)
{
    char rsp[160];
    if (strcmp(cmd, "PING") == 0) {
        send_to(handle, "{\"reply\":\"PONG\"}");
    } else if (strcmp(cmd, "START") == 0) {
        s_streaming = true;
        send_to(handle, "{\"streaming\":true}");
    } else if (strcmp(cmd, "STOP") == 0) {
        s_streaming = false;
        send_to(handle, "{\"streaming\":false}");
    } else if (strcmp(cmd, "STATUS") == 0) {
        snprintf(rsp, sizeof(rsp), "{\"connected\":true,\"streaming\":%s,\"period_ms\":%" PRIu32 ",\"samples\":%" PRIu32 "}",
                 s_streaming ? "true" : "false", s_period_ms, s_sample_id);
        send_to(handle, rsp);
    } else if (strncmp(cmd, "SET_RATE=", 9) == 0) {
        const char *p = cmd + 9;
        char *end = NULL;
        unsigned long value = strtoul(p, &end, 10);
        if (p != end && *end == '\0' && value >= MIN_PERIOD_MS && value <= MAX_PERIOD_MS) {
            s_period_ms = (uint32_t)value;
            snprintf(rsp, sizeof(rsp), "{\"period_ms\":%" PRIu32 "}", s_period_ms);
            send_to(handle, rsp);
        } else {
            send_to(handle, "{\"error\":\"rate must be 100..10000 ms\"}");
        }
    } else {
        send_to(handle, "{\"error\":\"unknown command\"}");
    }
}

static int gatt_access_cb(uint16_t conn_handle, uint16_t attr_handle,
                          struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    (void)attr_handle;
    if (ctxt->op == BLE_GATT_ACCESS_OP_READ_CHR) {
        return os_mbuf_append(ctxt->om, s_last_tx, strlen(s_last_tx)) == 0 ? 0 : BLE_ATT_ERR_INSUFFICIENT_RES;
    }
    if (ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR) {
        uint16_t len = OS_MBUF_PKTLEN(ctxt->om);
        if (len == 0 || len > CMD_MAX_LEN) return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        char cmd[CMD_MAX_LEN + 1];
        if (ble_hs_mbuf_to_flat(ctxt->om, cmd, len, NULL) != 0) return BLE_ATT_ERR_UNLIKELY;
        cmd[len] = '\0';
        /* Accept Android/iOS text commands with optional CR/LF. */
        while (len > 0 && (cmd[len - 1] == '\n' || cmd[len - 1] == '\r')) cmd[--len] = '\0';
        ESP_LOGI(TAG, "RX: %s", cmd);
        handle_command(conn_handle, cmd);
        return 0;
    }
    return BLE_ATT_ERR_UNLIKELY;
}

static const struct ble_gatt_svc_def s_gatt_services[] = {
    {
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = &s_service_uuid.u,
        .characteristics = (struct ble_gatt_chr_def[]) {
            { .uuid = &s_rx_uuid.u,
              .access_cb = gatt_access_cb,
              .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
            { .uuid = &s_tx_uuid.u,
              .access_cb = gatt_access_cb,
              .val_handle = &s_tx_val_handle,
              .flags = BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_NOTIFY },
            { 0 }
        }
    },
    { 0 }
};

static int gap_event_cb(struct ble_gap_event *event, void *arg);

static void advertise(void)
{
    struct ble_hs_adv_fields fields = {0};
    fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    fields.name = (const uint8_t *)DEVICE_NAME;
    fields.name_len = strlen(DEVICE_NAME);
    fields.name_is_complete = 1;
    int rc = ble_gap_adv_set_fields(&fields);
    if (rc != 0) { ESP_LOGE(TAG, "Adv data error=%d", rc); return; }

    struct ble_gap_adv_params params = {0};
    params.conn_mode = BLE_GAP_CONN_MODE_UND;
    params.disc_mode = BLE_GAP_DISC_MODE_GEN;
    if (s_client_count >= MAX_CLIENTS || ble_gap_adv_active()) return;
    rc = ble_gap_adv_start(s_addr_type, NULL, BLE_HS_FOREVER, &params, gap_event_cb, NULL);
    if (rc != 0) ESP_LOGE(TAG, "Adv start error=%d", rc);
    else ESP_LOGI(TAG, "Advertising: %s", DEVICE_NAME);
}

static int gap_event_cb(struct ble_gap_event *event, void *arg)
{
    (void)arg;
    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status == 0) {
            uint16_t handle = event->connect.conn_handle;
            ESP_LOGI(TAG, "Connected [%u]", handle);
            if (!client_add(handle)) {
                ESP_LOGW(TAG, "No free connection slot");
                ble_gap_terminate(handle, BLE_ERR_REM_USER_CONN_TERM);
                return 0;
            }
            if (s_client_count < MAX_CLIENTS) advertise();
        } else {
            ESP_LOGW(TAG, "Connection failed, status=%d", event->connect.status);
            advertise();
        }
        return 0;
    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "Disconnected [%u], reason=%d",
                 event->disconnect.conn.conn_handle, event->disconnect.reason);
        client_remove(event->disconnect.conn.conn_handle);
        advertise();
        return 0;
    case BLE_GAP_EVENT_ADV_COMPLETE:
        ESP_LOGI(TAG, "Advertising completed");
        advertise();
        return 0;
    case BLE_GAP_EVENT_SUBSCRIBE:
        if (event->subscribe.attr_handle == s_tx_val_handle) {
            int idx = client_index(event->subscribe.conn_handle);
            if (idx >= 0) {
                s_clients[idx].subscribed = event->subscribe.cur_notify != 0;
                ESP_LOGI(TAG, "TX Notify [%u]: %s", event->subscribe.conn_handle,
                         s_clients[idx].subscribed ? "ON" : "OFF");
            }
        }
        return 0;
    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU [%u] = %u", event->mtu.conn_handle, event->mtu.value);
        return 0;
    default:
        return 0;
    }
}

static void on_reset(int reason)
{
    ESP_LOGW(TAG, "BLE stack reset=%d", reason);
    s_client_count = 0;
    for (unsigned i = 0; i < MAX_CLIENTS; ++i) {
        s_clients[i].handle = INVALID_CONN_HANDLE;
        s_clients[i].subscribed = false;
    }
}

static void on_sync(void)
{
    int rc = ble_hs_util_ensure_addr(0);
    if (rc != 0) { ESP_LOGE(TAG, "BLE address error=%d", rc); return; }
    rc = ble_hs_id_infer_auto(0, &s_addr_type);
    if (rc != 0) { ESP_LOGE(TAG, "BLE address type error=%d", rc); return; }
    advertise();
}

static void host_task(void *param)
{
    (void)param;
    nimble_port_run();
    nimble_port_freertos_deinit();
}

static void simulator_task(void *param)
{
    (void)param;
    uint64_t next_ms = 0;
    for (;;) {
        uint64_t now_ms = (uint64_t)(esp_timer_get_time() / 1000);
        if (s_streaming && any_subscribed() && now_ms >= next_ms) {
            ++s_sample_id;
            /* Integer synthetic waveform: no ADC, camera, battery, or sensor is read. */
            uint32_t phase = s_sample_id % 40U;
            int32_t temp_x10 = 245 + (int32_t)(phase <= 20 ? phase : 40U - phase);
            uint32_t hum_x10 = 520 + ((s_sample_id * 7U) % 80U);
            uint32_t batt_mv = 3800U + ((s_sample_id * 13U) % 300U);
            char data[160];
            snprintf(data, sizeof(data),
                     "{\"seq\":%" PRIu32 ",\"temp_c_x10\":%" PRId32 ",\"rh_x10\":%" PRIu32
                     ",\"batt_mv\":%" PRIu32 ",\"up_s\":%" PRIu64 "}",
                     s_sample_id, temp_x10, hum_x10, batt_mv, now_ms / 1000U);
            send_all(data);
            next_ms = now_ms + s_period_ms;
        }
        if (!s_streaming || !any_subscribed()) {
            next_ms = now_ms; /* send promptly after START / reconnect / subscribe */
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "SaturnVex ESP32-S3 BLE Multi-client Link Test starting");
    for (unsigned i = 0; i < MAX_CLIENTS; ++i) {
        s_clients[i].handle = INVALID_CONN_HANDLE;
        s_clients[i].subscribed = false;
    }
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);
    ESP_ERROR_CHECK(nimble_port_init());
    ble_hs_cfg.reset_cb = on_reset;
    ble_hs_cfg.sync_cb = on_sync;
    ble_svc_gap_init();
    ble_svc_gatt_init();
    ble_att_set_preferred_mtu(185); /* Phone must also negotiate MTU >= ~100 for full JSON notifications. */
    int rc = ble_svc_gap_device_name_set(DEVICE_NAME);
    ESP_ERROR_CHECK(rc == 0 ? ESP_OK : ESP_FAIL);
    rc = ble_gatts_count_cfg(s_gatt_services);
    ESP_ERROR_CHECK(rc == 0 ? ESP_OK : ESP_FAIL);
    rc = ble_gatts_add_svcs(s_gatt_services);
    ESP_ERROR_CHECK(rc == 0 ? ESP_OK : ESP_FAIL);
    nimble_port_freertos_init(host_task);
    BaseType_t created = xTaskCreate(simulator_task, "simulator", 4096, NULL, 5, NULL);
    configASSERT(created == pdPASS);
}
