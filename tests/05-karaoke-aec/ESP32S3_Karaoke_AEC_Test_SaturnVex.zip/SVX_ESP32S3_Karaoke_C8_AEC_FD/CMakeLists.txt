cmake_minimum_required(VERSION 3.16)
include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(SVX_ESP32S3_Karaoke_C8_AEC_FD)
# ESP-IDF v6.1 compatibility for esp_codec_dev 1.5.1: pre-include esp_idf_version.h.
idf_component_get_property(_svx_codec_target espressif__esp_codec_dev COMPONENT_LIB)
if(NOT _svx_codec_target)
    message(FATAL_ERROR "esp_codec_dev component not found")
endif()
target_compile_options(${_svx_codec_target} PRIVATE -include esp_idf_version.h)
