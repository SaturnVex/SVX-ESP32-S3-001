idf_component_register(SRCS "main.c" INCLUDE_DIRS "." REQUIRES esp_driver_i2c esp_driver_i2s esp_codec_dev esp-sr esp_timer)
