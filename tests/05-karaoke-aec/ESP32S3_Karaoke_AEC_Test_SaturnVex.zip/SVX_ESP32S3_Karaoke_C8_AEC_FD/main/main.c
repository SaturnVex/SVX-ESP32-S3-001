/*
 * SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
 *
 * Project : SVX_ESP32S3_Karaoke_C8_AEC_FD
 * File    : main/main.c
 * Board   : SVX-ESP32-S3-001 (ESP32-S3), ESP-IDF v6.1
 * Purpose : Real-time microphone-to-speaker audio with Espressif ESP-SR FD AEC
 *           (application revision C8.21): ES7210 MIC input -> AEC, 70 Hz HPF,
 *           feedback notch and peak limiter -> ES8311 / NS4150 speaker.
 *
 * I2S0 full duplex (shared BCLK/WS/MCLK, 32-bit stereo at 16 kHz):
 * MCLK GPIO47, BCLK GPIO14, WS GPIO13, TX GPIO21, RX GPIO48.
 * I2C0: SCL GPIO1, SDA GPIO2. ES8311 = 0x18, ES7210 = 0x40.
 * NS4150 enable is via the board hardware pull-up (no firmware GPIO).
 * AEC reference = most recent PCM queued to ES8311 (approximate delay).
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "esp_heap_caps.h"
#include "esp_aec.h"
#include "esp_timer.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/i2c_master.h"
#include "driver/i2s_std.h"
#include "esp_codec_dev.h"
#include "esp_codec_dev_defaults.h"
#include "es7210_adc.h"
#include "es8311_codec.h"

#define I2C_SCL_PIN           1
#define I2C_SDA_PIN           2
#define ES8311_ADDR           0x18
#define ES7210_ADDR           0x40
#define MCLK_PIN              47
#define BCLK_PIN              14
#define WS_PIN                13
#define DOUT_PIN              21
#define DIN_PIN               48

#define SAMPLE_RATE_HZ        16000
#define AUDIO_BITS            32
#define CHANNELS              2
#define BLOCK_FRAMES          256
#define MIC_GAIN_DB           37.5f  /* MIC2 proven in C8.7 baseline */
#define SPEAKER_VOLUME        85     /* C8.21: DAC 85/100, gain remains fixed at 8x */
#define NOISE_CAL_BLOCKS      63     /* ~1 second */
#define SPEECH_RMS_FLOOR      7.0    /* min gate in int16 PCM counts */
#define DETECT_NOISE_FACTOR   4.0

static const char *TAG = "SVX_KARAOKE_C8_21";

static i2c_master_bus_handle_t s_bus;
static i2s_chan_handle_t s_tx;
static i2s_chan_handle_t s_rx;
static esp_codec_dev_handle_t s_speaker;
static esp_codec_dev_handle_t s_mic;

static esp_err_t setup_bus(void)
{
    i2c_master_bus_config_t cfg = {
        .i2c_port = I2C_NUM_0,
        .sda_io_num = I2C_SDA_PIN,
        .scl_io_num = I2C_SCL_PIN,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    return i2c_new_master_bus(&cfg, &s_bus);
}

static esp_err_t setup_i2s_full_duplex(void)
{
    /* Create TX and RX TOGETHER on I2S0; full-duplex shares clock domain. */
    i2s_chan_config_t chan = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    chan.dma_desc_num = 6;
    chan.dma_frame_num = BLOCK_FRAMES;
    ESP_RETURN_ON_ERROR(i2s_new_channel(&chan, &s_tx, &s_rx),
                        TAG, "create TX/RX pair");
    i2s_std_config_t cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(SAMPLE_RATE_HZ),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT,
                                                        I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = MCLK_PIN,
            .bclk = BCLK_PIN,
            .ws = WS_PIN,
            .dout = DOUT_PIN,
            .din = DIN_PIN,
        },
    };
    ESP_RETURN_ON_ERROR(i2s_channel_init_std_mode(s_tx, &cfg),
                        TAG, "init full-duplex TX");
    ESP_RETURN_ON_ERROR(i2s_channel_init_std_mode(s_rx, &cfg),
                        TAG, "init full-duplex RX");
    return ESP_OK;
}

static esp_err_t setup_speaker(void)
{
    audio_codec_i2c_cfg_t i2c = {
        .addr = ES8311_CODEC_DEFAULT_ADDR,
        .bus_handle = s_bus,
    };
    const audio_codec_ctrl_if_t *ctrl = audio_codec_new_i2c_ctrl(&i2c);
    const audio_codec_gpio_if_t *gpio = audio_codec_new_gpio();
    audio_codec_i2s_cfg_t i2s = {
        .port = I2S_NUM_0,
        .rx_handle = NULL,
        .tx_handle = s_tx,
    };
    const audio_codec_data_if_t *data = audio_codec_new_i2s_data(&i2s);
    if (!ctrl || !gpio || !data) return ESP_ERR_NO_MEM;
    es8311_codec_cfg_t ccfg = {
        .ctrl_if = ctrl,
        .gpio_if = gpio,
        .codec_mode = ESP_CODEC_DEV_WORK_MODE_DAC,
        .pa_pin = -1,
        .use_mclk = true,
        .master_mode = false,
    };
    const audio_codec_if_t *codec = es8311_codec_new(&ccfg);
    if (!codec) return ESP_FAIL;
    esp_codec_dev_cfg_t dc = {
        .codec_if = codec,
        .data_if = data,
        .dev_type = ESP_CODEC_DEV_TYPE_OUT,
    };
    s_speaker = esp_codec_dev_new(&dc);
    if (!s_speaker) return ESP_ERR_NO_MEM;

    esp_codec_dev_sample_info_t fmt = {
        .sample_rate = SAMPLE_RATE_HZ,
        .channel = CHANNELS,
        .bits_per_sample = AUDIO_BITS,
    };
    int rc = esp_codec_dev_open(s_speaker, &fmt);
    if (rc != 0) { ESP_LOGE(TAG, "ES8311 open rc=%d", rc); return ESP_FAIL; }
    rc = esp_codec_dev_set_out_vol(s_speaker, SPEAKER_VOLUME);
    if (rc != 0) { ESP_LOGE(TAG, "ES8311 volume rc=%d", rc); return ESP_FAIL; }
    rc = esp_codec_dev_set_out_mute(s_speaker, false);
    if (rc != 0) { ESP_LOGE(TAG, "ES8311 unmute rc=%d", rc); return ESP_FAIL; }
    rc = esp_codec_dev_set_out_mute(s_speaker, true);
    if (rc != 0) { ESP_LOGE(TAG, "ES8311 initial mute rc=%d", rc); return ESP_FAIL; }
    ESP_LOGI(TAG, "PASS ES8311 32-bit stereo, volume=%d, initially MUTED", SPEAKER_VOLUME);
    return ESP_OK;
}

static esp_err_t setup_mic(void)
{
    audio_codec_i2c_cfg_t i2c = {
        .addr = ES7210_CODEC_DEFAULT_ADDR,
        .bus_handle = s_bus,
    };
    const audio_codec_ctrl_if_t *ctrl = audio_codec_new_i2c_ctrl(&i2c);
    audio_codec_i2s_cfg_t i2s = {
        .port = I2S_NUM_0,
        .rx_handle = s_rx,
        .tx_handle = NULL,
    };
    const audio_codec_data_if_t *data = audio_codec_new_i2s_data(&i2s);
    if (!ctrl || !data) return ESP_ERR_NO_MEM;
    es7210_codec_cfg_t ccfg = {
        .ctrl_if = ctrl,
        .mic_selected = ES7210_SEL_MIC1 | ES7210_SEL_MIC2,
        .master_mode = false,
    };
    const audio_codec_if_t *codec = es7210_codec_new(&ccfg);
    if (!codec) return ESP_FAIL;
    esp_codec_dev_cfg_t dc = {
        .codec_if = codec,
        .data_if = data,
        .dev_type = ESP_CODEC_DEV_TYPE_IN,
    };
    s_mic = esp_codec_dev_new(&dc);
    if (!s_mic) return ESP_ERR_NO_MEM;

    esp_codec_dev_sample_info_t fmt = {
        .sample_rate = SAMPLE_RATE_HZ,
        .channel = CHANNELS,
        .bits_per_sample = AUDIO_BITS,
    };
    int rc = esp_codec_dev_open(s_mic, &fmt);
    if (rc != 0) { ESP_LOGE(TAG, "ES7210 open rc=%d", rc); return ESP_FAIL; }
    rc = esp_codec_dev_set_in_gain(s_mic, MIC_GAIN_DB);
    if (rc != 0) { ESP_LOGE(TAG, "ES7210 gain rc=%d", rc); return ESP_FAIL; }
    ESP_LOGI(TAG, "PASS ES7210 MIC1/MIC2, 32-bit stereo, gain %.1fdB",
             (double)MIC_GAIN_DB);
    return ESP_OK;
}




/* ESP-SR full-duplex AEC.
 * The direct AEC API expects aligned int16_t mono input/ref/output. We feed
 * two microphone channels mixed to mono and the EXACT prior DAC PCM mono
 * block as the reference. ES8311 volume scaling / physical acoustic delay
 * remains an imperfect transfer path and must be tuned on the actual board.
 *
 * IMPORTANT: Feedback monitoring using speaker+mic on the same enclosure can
 * howl even with AEC. Hard cap output and latch mute on unsafe levels.
 */
#define C8_MAX_FRAME_SAMPLES      1024
/* A protective per-frame peak limiter reduces gain ONLY when the fixed gain would exceed the ceiling.
 * Release is slow; attack is immediate to avoid transient clipping. */
/* C8.21: gate low-level noise / echo in the PA speaker path.
 * These thresholds are not used in the active signal path.
 * This is NOT a voice-activity detector or a feedback suppressor.
 */
#define C815_UNUSED_GATE_OPEN_MIC_RMS   40.0
#define C814_GATE_CLOSE_MIC_RMS  22.0
#define C814_GATE_OPEN_AEC_RMS   18.0
#define C814_GATE_CLOSE_AEC_RMS   9.0
#define C814_GATE_ATTACK_FRAMES   2
#define C814_GATE_HOLD_FRAMES     8
#define C814_GATE_FADE_IN_STEP  0.20f
#define C814_GATE_FADE_OUT_STEP 0.10f

/* C8.21: optional single-pole high-pass at 70 Hz. It removes DC and
 * handling/low-frequency rumble without time-varying speech gain.
 * To compare the original voice, set C818_HPF_ENABLE to 0 and rebuild.
 * This does NOT suppress howling or fix an AEC reference delay. */
#define C818_HPF_ENABLE         1
#define C818_HPF_CUTOFF_HZ      70.0f

/* C8.21 experimental acoustic feedback suppressor (AFS).
 * Detect a stable, isolated whistle in AEC output with Goertzel bins.
 * Never mistake a short sung note for feedback: requires persistence (~1 s).
 * Only one narrow notch is allowed; singing can still falsely activate it.
 * Disable with C821_AFS_ENABLE=0 to A/B test without changing codec levels.
 */
#define C821_AFS_ENABLE              1
#define C821_AFS_MIN_HZ             300
#define C821_AFS_MAX_HZ            3000
#define C821_AFS_BIN_STEP             2   /* FFT-like bins, 62.5 Hz apart at 16k/512 */
#define C821_AFS_MIN_RMS           110.0f
#define C821_AFS_TONAL_FRACTION      0.30f
#define C821_AFS_REQUIRED_SCANS       8   /* 8 * 4 * 32ms = 1024ms */
#define C821_AFS_SCAN_EVERY_FRAMES    4
#define C821_AFS_Q                 16.0f  /* narrow notch */
#define C821_AFS_MAX_HOLD_SCANS     120   /* 15.36 seconds without same tone */
#define C821_AFS_WET_STEP          0.16f  /* fade in/out, no fullband gain change */
/* Avoid mistaking pitched speech/singing with strong harmonics for feedback.
 * Harmonicity test is heuristic; real feedback can coexist with music.
 * Slight bin shifts are tracked using parabolic spectral interpolation. */
#define C821_AFS_HARMONIC_RATIO_MAX 0.085f /* fractional total power at 2f + 3f */
#define C821_AFS_STABLE_FREQ_TOL_HZ 23.0f


typedef struct {
    float b0, b1, b2, a1, a2;
    float x1, x2, y1, y2;
    float wet;
    float freq_hz;
    float candidate_hz;
    float detected_hz;
    float harmonic_ratio;
    unsigned int harmonic_rejects;
    unsigned int stable_count;
    unsigned int matching_silence_scans;
    unsigned int activations;
    int candidate_bin;
    bool engaged;
    bool enabled;
} c821_afs_t;

static int32_t c8_clamp(int32_t x, int32_t lim);
static c821_afs_t s_afs = {.candidate_bin = -1};

/* Magnitude of one DFT bin, normalized to total frame energy.
 * For a pure bin-centered sinusoid, ratio approaches 0.5.
 * White/noise-like signals yield much smaller ratios. */
static float c821_goertzel_ratio(const int16_t *pcm, int n, int k, double energy)
{
    if (energy < 1.0 || n <= 0) return 0.0f;
    const float omega = 6.2831853071795864769f * (float)k / (float)n;
    const float coeff = 2.0f * cosf(omega);
    float q0, q1 = 0.0f, q2 = 0.0f;
    for (int i = 0; i < n; ++i) {
        q0 = (float)pcm[i] + coeff*q1 - q2;
        q2 = q1;
        q1 = q0;
    }
    const double power = (double)q1*q1 + (double)q2*q2 - (double)coeff*q1*q2;
    return (float)(fmax(0.0, power) / ((double)n * energy));
}

static void c821_afs_set_notch(float hz)
{
    const float w = 6.2831853071795864769f * hz / (float)SAMPLE_RATE_HZ;
    const float alpha = sinf(w) / (2.0f*C821_AFS_Q);
    const float a0 = 1.0f + alpha;
    s_afs.b0 = 1.0f / a0;
    s_afs.b1 = -2.0f*cosf(w) / a0;
    s_afs.b2 = 1.0f / a0;
    s_afs.a1 = s_afs.b1;
    s_afs.a2 = (1.0f-alpha)/a0;
    s_afs.x1 = s_afs.x2 = s_afs.y1 = s_afs.y2 = 0.0f;
    s_afs.freq_hz = hz;
}

/* C8.21: harmonic-aware, refined stationary-tone detector.
 * The 512-sample frame has bin spacing 31.25 Hz. We coarse-scan every two
 * bins, then examine neighbors and interpolate the peak in log-power.
 * We reject strong 2nd/3rd harmonics because they are common in singing.
 * This is NOT a voice/music classifier or a certified anti-feedback system. */
static void c821_afs_detect(const int16_t *pcm, int n, uint32_t block)
{
#if C821_AFS_ENABLE
    if (block % C821_AFS_SCAN_EVERY_FRAMES != 0) return;
    double energy = 0.0;
    for (int i = 0; i < n; ++i) energy += (double)pcm[i] * (double)pcm[i];
    const float rms = (float)sqrt(energy / (double)n);
    float best_ratio = 0.0f;
    int best_bin = -1;
    const float bin_hz = (float)SAMPLE_RATE_HZ / (float)n;
    int low_bin = (C821_AFS_MIN_HZ * n + SAMPLE_RATE_HZ - 1) / SAMPLE_RATE_HZ;
    int high_bin = (C821_AFS_MAX_HZ * n) / SAMPLE_RATE_HZ;
    if (high_bin > n / 2 - 2) high_bin = n / 2 - 2;
    if (rms >= C821_AFS_MIN_RMS) {
        for (int k = low_bin; k <= high_bin; k += C821_AFS_BIN_STEP) {
            const float ratio = c821_goertzel_ratio(pcm, n, k, energy);
            if (ratio > best_ratio) { best_ratio = ratio; best_bin = k; }
        }
    }
    /* Refine coarse-bin result and estimate frequency between DFT bins. */
    float hz = 0.0f;
    if (best_bin > 1) {
        int peak_bin = best_bin;
        for (int k = best_bin - 1; k <= best_bin + 1; ++k) {
            const float r = c821_goertzel_ratio(pcm, n, k, energy);
            if (r > best_ratio) { best_ratio = r; peak_bin = k; }
        }
        const float left = c821_goertzel_ratio(pcm, n, peak_bin - 1, energy);
        const float right = c821_goertzel_ratio(pcm, n, peak_bin + 1, energy);
        /* A log-power parabola reduces frequency quantization error. */
        const float L = logf(fmaxf(left, 1.0e-9f));
        const float M = logf(fmaxf(best_ratio, 1.0e-9f));
        const float R = logf(fmaxf(right, 1.0e-9f));
        const float denom = (L - 2.0f * M + R);
        float delta = 0.0f;
        if (fabsf(denom) > 0.0001f) delta = 0.5f * (L - R) / denom;
        delta = fmaxf(-0.5f, fminf(0.5f, delta));
        hz = (peak_bin + delta) * bin_hz;
    }
    bool tonal = best_bin >= 0 && best_ratio >= C821_AFS_TONAL_FRACTION;
    /* A musical note normally has a harmonic series. Use both 2f and 3f
     * where available; rejecting such notes avoids unnecessary notch usage. */
    float harmonic = 0.0f;
    if (tonal) {
        for (int mul = 2; mul <= 3; ++mul) {
            const int hk = (int)lroundf(hz * (float)mul / bin_hz);
            if (hk <= 1 || hk >= n / 2 - 1) continue;
            const float h0 = c821_goertzel_ratio(pcm, n, hk, energy);
            const float hm = c821_goertzel_ratio(pcm, n, hk - 1, energy);
            const float hp = c821_goertzel_ratio(pcm, n, hk + 1, energy);
            harmonic += fmaxf(h0, fmaxf(hm, hp));
        }
        if (harmonic >= C821_AFS_HARMONIC_RATIO_MAX) {
            tonal = false;
            ++s_afs.harmonic_rejects;
        }
    }
    s_afs.detected_hz = hz;
    s_afs.harmonic_ratio = harmonic;
    if (s_afs.engaged) {
        /* Release a notch if the same isolated feedback-like tone disappears. */
        if (tonal && fabsf(hz - s_afs.freq_hz) <= C821_AFS_STABLE_FREQ_TOL_HZ)
            s_afs.matching_silence_scans = 0;
        else if (++s_afs.matching_silence_scans >= C821_AFS_MAX_HOLD_SCANS)
            s_afs.engaged = false;
        return;
    }
    if (!tonal) {
        s_afs.stable_count = 0;
        s_afs.candidate_bin = -1;
        s_afs.candidate_hz = 0.0f;
        return;
    }
    if (s_afs.stable_count != 0 &&
        fabsf(hz - s_afs.candidate_hz) <= C821_AFS_STABLE_FREQ_TOL_HZ) {
        if (s_afs.stable_count < C821_AFS_REQUIRED_SCANS) ++s_afs.stable_count;
        /* Avoid resetting the filter frequency for minor analysis jitter. */
        s_afs.candidate_hz = 0.8f*s_afs.candidate_hz + 0.2f*hz;
    } else {
        s_afs.candidate_hz = hz;
        s_afs.candidate_bin = best_bin;
        s_afs.stable_count = 1;
    }
    if (s_afs.stable_count >= C821_AFS_REQUIRED_SCANS) {
        const float notch_hz = s_afs.candidate_hz;
        c821_afs_set_notch(notch_hz);
        s_afs.engaged = true;
        s_afs.matching_silence_scans = 0;
        ++s_afs.activations;
        ESP_LOGW(TAG, "C8.21 AFS notch ENGAGED: %.1fHz tonal=%.2f harmonic=%.3f RMS=%.1f",
                 (double)notch_hz, (double)best_ratio, (double)harmonic, (double)rms);
        s_afs.stable_count = 0;
        s_afs.candidate_bin = -1;
        s_afs.candidate_hz = 0.0f;
    }
#else
    (void)pcm; (void)n; (void)block;
#endif
}

static void c821_afs_process(int16_t *pcm, int n)
{
#if C821_AFS_ENABLE
    const float desired = s_afs.engaged ? 1.0f : 0.0f;
    /* Fade at sample granularity (~6ms), no jumps at block boundaries. */
    const float wet_inc = C821_AFS_WET_STEP/512.0f;
    for (int i=0; i<n; ++i) {
        float x = (float)pcm[i];
        if (s_afs.wet < desired) s_afs.wet=fminf(desired,s_afs.wet+wet_inc);
        else if (s_afs.wet > desired) s_afs.wet=fmaxf(desired,s_afs.wet-wet_inc);
        if (!s_afs.engaged && s_afs.wet <= 0.0f) continue;
        float yf = s_afs.b0*x + s_afs.b1*s_afs.x1 + s_afs.b2*s_afs.x2
                 - s_afs.a1*s_afs.y1 - s_afs.a2*s_afs.y2;
        s_afs.x2=s_afs.x1; s_afs.x1=x;
        s_afs.y2=s_afs.y1; s_afs.y1=yf;
        float out=x + s_afs.wet*(yf-x);
        pcm[i]=(int16_t)c8_clamp((int32_t)out,32767);
    }
#else
    (void)pcm; (void)n;
#endif
}

#define C810_MAX_GAIN             8.0f
#define C810_TARGET_PEAK16        11000.0f /* +3.33 dB headroom vs C8.20 */
#define C818_LIMITER_RELEASE_STEP 0.12f   /* max gain recovery per 32ms frame (~1.5s from 2x to 8x) */
#define C8_OUTPUT_PEAK16         12000 /* hard fail-safe above nominal ceiling */
/* A spoken syllable can exceed 300 RMS and ~1200 peak on this board.
 * C8.10 tripped on normal voice (RMS=324.4, peak=1163).
 * Use separate short catastrophic overload and sustained high-energy guards.
 * This is NOT a substitute for AEC or reliable acoustic howling detection. */
#define C812_HIGH_MIC_RMS16       900.0
#define C812_HIGH_RMS_FRAMES      10  /* ~320 ms at 16 kHz / 512 samples */
#define C812_CRITICAL_MIC_RMS16   3000.0
#define C812_CRITICAL_MIC_PEAK16  12000
#define C812_CRITICAL_FRAMES      1  /* immediately mute for an extreme spike */
/* Gain reduction starts before an unsafe continuous level develops. */
#define C812_DUCK_START_RMS16     350.0
#define C812_DUCK_FULL_RMS16      1100.0
#define C812_MIN_DUCK_FACTOR      0.30f
/* Recoverable acoustic overload control. A large transient immediately mutes
 * the DAC; the loudspeaker is only enabled after sustained quiet. Three
 * overloads within 30s latch off, avoiding repeated howl/auto-restart cycles. */
#define C812_RECOVERY_QUIET_RMS16     130.0
#define C812_RECOVERY_QUIET_PEAK16    800
#define C812_RECOVERY_QUIET_FRAMES    24  /* 768ms */
#define C812_MIN_MUTED_FRAMES         32  /* 1024ms */
#define C812_MAX_TRIPS_WINDOW         3
#define C812_TRIP_WINDOW_US           30000000LL

#define C8_MAX_SECONDS           0 /* no time-based automatic stop; safety trip still active */
#define C8_START_FADE_BLOCKS      12
#define C8_REPORT_EVERY_MS       1000
#define C8_MAX_IO_ERRORS         4
#define C81_AEC_MUTED_PREFLIGHT_BLOCKS  10
#define C81_GUARD_BYTES                64
#define C81_GUARD_FILL                 0xA7

/* C8.21 quality A/B: NORMAL is less aggressive than AGGR and may keep
 * more vocal detail, but cancellation may get weaker. If echo increases,
 * set this switch to 0, which restores the C8.20 AGGR behavior. */
#define C821_AEC_NLP_NORMAL 1

static aec_handle_t *s_aec;
static int s_aec_frames;
static int16_t *s_aec_mic, *s_aec_ref, *s_aec_out;
static int16_t *s_ref_previous;
static int32_t *s_pcm_rx, *s_pcm_tx;
static size_t s_aec_n16;
static size_t s_aec_n32;

/* Dedicated TX feeder: RX/AEC processing and DAC writes run in separate
 * tasks so that the TX DMA is fed continuously.
 *
 * ESP-SR AEC reference is the most recent PCM SUBMITTED to the DAC feeder,
 * not an exact timestamp-aligned acoustic reference. Hardware alignment is
 * still needed for best echo suppression.
 */
#define C85_TX_QUEUE_LEN 3
#define C85_TX_STACK_BYTES 8192
#define C85_TX_MAX_FRAMES C8_MAX_FRAME_SAMPLES

typedef struct {
    int32_t pcm[C85_TX_MAX_FRAMES * CHANNELS];
    int16_t ref[C85_TX_MAX_FRAMES];
} c85_tx_block_t;

static QueueHandle_t s_tx_queue;
static volatile bool s_tx_stop = false;
static volatile bool s_tx_active = false;
/* Gate feeder PCM during an acoustic overload, even when stale frames remain queued. */
static volatile bool s_tx_audio_allowed = false;
static uint32_t s_tx_ok = 0, s_tx_zeros = 0, s_tx_fail = 0, s_tx_qdrop = 0;
static int16_t *s_tx_last_ref;
static portMUX_TYPE s_tx_ref_mux = portMUX_INITIALIZER_UNLOCKED;

static void c85_tx_task(void *arg)
{
    (void)arg;
    const size_t io_bytes = (size_t)s_aec_frames * CHANNELS * sizeof(int32_t);
    const size_t ref_bytes = (size_t)s_aec_frames * sizeof(int16_t);
    c85_tx_block_t *item = heap_caps_calloc(1, sizeof(*item), MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    int32_t *zeros = heap_caps_calloc(1, io_bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (!item || !zeros) {
        ESP_LOGE(TAG, "C8.21 TX feeder allocation failed");
        ++s_tx_fail;
        free(item); free(zeros);
        s_tx_active = false;
        vTaskDelete(NULL);
    }
    while (!s_tx_stop) {
        /* Timeout is short; a silent frame is written instead of allowing TX
         * DMA starvation while the AEC task computes or waits for RX. */
        bool has_frame = xQueueReceive(s_tx_queue, item, pdMS_TO_TICKS(1)) == pdTRUE;
        const bool play_audio = has_frame && s_tx_audio_allowed;
        const int32_t *pcm = play_audio ? item->pcm : zeros;
        int rc = esp_codec_dev_write(s_speaker, (void *)pcm, io_bytes);
        if (rc != 0) {
            ++s_tx_fail;
            ESP_LOGE(TAG, "C8.21 TX feeder write rc=%d", rc);
            s_tx_stop = true;
            esp_codec_dev_set_out_mute(s_speaker, true);
            break;
        }
        if (play_audio) ++s_tx_ok;
        else ++s_tx_zeros;
        portENTER_CRITICAL(&s_tx_ref_mux);
        if (play_audio) memcpy(s_tx_last_ref, item->ref, ref_bytes);
        else memset(s_tx_last_ref, 0, ref_bytes);
        portEXIT_CRITICAL(&s_tx_ref_mux);
    }
    free(item); free(zeros);
    s_tx_active = false;
    vTaskDelete(NULL);
}

static esp_err_t c85_start_tx(void)
{
    s_tx_queue = xQueueCreate(C85_TX_QUEUE_LEN, sizeof(c85_tx_block_t));
    s_tx_last_ref = heap_caps_calloc(s_aec_frames, sizeof(int16_t), MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (!s_tx_queue || !s_tx_last_ref) return ESP_ERR_NO_MEM;
    s_tx_active = true;
    BaseType_t rc = xTaskCreatePinnedToCore(c85_tx_task, "svx_tx_feeder",
                                             C85_TX_STACK_BYTES, NULL, 6, NULL, 0);
    if (rc != pdPASS) {
        s_tx_active = false;
        return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}


static bool c81_guard_ok(const void *buffer, size_t used, const char *name)
{
    const uint8_t *tail = (const uint8_t *)buffer + used;
    for (size_t i = 0; i < C81_GUARD_BYTES; ++i) {
        if (tail[i] != C81_GUARD_FILL) {
            ESP_LOGE(TAG, "C8.1 MEMORY CORRUPTION: %s guard offset=%u value=0x%02x", name,
                     (unsigned)i, (unsigned)tail[i]);
            return false;
        }
    }
    return true;
}

static bool c81_check_guards(void)
{
    return c81_guard_ok(s_aec_mic, s_aec_n16, "aec_mic") &&
           c81_guard_ok(s_aec_ref, s_aec_n16, "aec_ref") &&
           c81_guard_ok(s_aec_out, s_aec_n16, "aec_out") &&
           c81_guard_ok(s_ref_previous, s_aec_n16, "previous_ref") &&
           c81_guard_ok(s_pcm_rx, s_aec_n32, "pcm_rx") &&
           c81_guard_ok(s_pcm_tx, s_aec_n32, "pcm_tx");
}


static void c8_muted(const char *reason)
{
    s_tx_audio_allowed = false;
    s_tx_stop = true;
    if (s_speaker) esp_codec_dev_set_out_mute(s_speaker, true);
    ESP_LOGW(TAG, "C8 MUTED / LATCHED STOP: %s; reset board to restart", reason);
}

static int32_t c8_clamp(int32_t x, int32_t lim)
{
    if (x > lim) return lim;
    if (x < -lim) return -lim;
    return x;
}

static esp_err_t c8_init_aec(void)
{
    /* Espressif recommends FD_LOW_COST on ESP32-S3 for real-time full duplex. */
    aec_config_t cfg = {
        .mic_num = 1,
        .ref_num = 1,
        .out_num = 1,
        .filter_length = 4,
        .sample_rate = SAMPLE_RATE_HZ,
        .caps = MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT,
        .mode = AEC_MODE_FD_LOW_COST,
        .nlp_level = C821_AEC_NLP_NORMAL ? AEC_NLP_LEVEL_NORMAL : AEC_NLP_LEVEL_AGGR,
    };
    s_aec = aec_create_from_config(&cfg);
    if (!s_aec) { ESP_LOGE(TAG, "AEC create failed: check PSRAM and esp-sr config"); return ESP_FAIL; }
    s_aec_frames = aec_get_chunksize(s_aec);
    if (s_aec_frames <= 0 || s_aec_frames > C8_MAX_FRAME_SAMPLES) {
        ESP_LOGE(TAG, "Unexpected AEC frame=%d (> %d)", s_aec_frames, C8_MAX_FRAME_SAMPLES);
        return ESP_FAIL;
    }
    const size_t n16 = (size_t)s_aec_frames * sizeof(int16_t);
    const size_t n32 = (size_t)s_aec_frames * CHANNELS * sizeof(int32_t);
    /* Allocate guard bytes after every buffer. If the proprietary AEC library
     * or codec I/O overruns a frame, keep the speaker muted and report which
     * buffer was overwritten. Alignment remains 16 bytes. */
    s_aec_n16 = n16;
    s_aec_n32 = n32;
    s_aec_mic = heap_caps_aligned_alloc(16, n16 + C81_GUARD_BYTES, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_aec_ref = heap_caps_aligned_alloc(16, n16 + C81_GUARD_BYTES, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_aec_out = heap_caps_aligned_alloc(16, n16 + C81_GUARD_BYTES, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_ref_previous = heap_caps_aligned_alloc(16, n16 + C81_GUARD_BYTES, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_pcm_rx = heap_caps_aligned_alloc(16, n32 + C81_GUARD_BYTES, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_pcm_tx = heap_caps_aligned_alloc(16, n32 + C81_GUARD_BYTES, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (!s_aec_mic || !s_aec_ref || !s_aec_out || !s_ref_previous || !s_pcm_rx || !s_pcm_tx) {
        ESP_LOGE(TAG, "Out of internal DRAM for AEC frame buffers"); return ESP_ERR_NO_MEM;
    }
    uint8_t *bufs[] = {(uint8_t *)s_aec_mic, (uint8_t *)s_aec_ref,
                       (uint8_t *)s_aec_out, (uint8_t *)s_ref_previous,
                       (uint8_t *)s_pcm_rx, (uint8_t *)s_pcm_tx};
    for (int i = 0; i < 6; ++i) {
        size_t used = i < 4 ? n16 : n32;
        memset(bufs[i], 0, used);
        memset(bufs[i] + used, C81_GUARD_FILL, C81_GUARD_BYTES);
    }
    ESP_LOGI(TAG, "C8 AEC initialized: frame=%d (%.1f ms), FD_LOW_COST, filter=4, PSRAM free=%lu",
             s_aec_frames, s_aec_frames * 1000.0 / SAMPLE_RATE_HZ,
             (unsigned long)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    return ESP_OK;
}

static void c8_stream(void)
{
    const int frame = s_aec_frames;
    const size_t io_bytes = (size_t)frame * CHANNELS * sizeof(int32_t);
    const size_t ref_bytes = (size_t)frame * sizeof(int16_t);
    /* Static to keep ~10KB queue item off stack (C5 stack overflow history). */
    static c85_tx_block_t queue_item;
    unsigned int errors = 0;
    unsigned int high_rms_frames = 0;
    unsigned int critical_frames = 0;
    unsigned int quiet_frames = 0;
    unsigned int muted_frames = 0;
    unsigned int recovery_count = 0;
    int64_t trip_window_start = 0;
    bool overload_muted = false;
    uint32_t block = 0;
    uint32_t max_mic = 0, max_aec = 0, max_out = 0;
    const int64_t begun = esp_timer_get_time();
    int64_t log_at = begun;
    bool started = false;
    unsigned int safe_preflight = 0;
    double last_rms = 0;
    float last_gain = C810_MAX_GAIN;
    float prior_gain = C810_MAX_GAIN;
    uint32_t limiter_attenuated_blocks = 0;
    uint32_t peak_limited_blocks = 0;
    uint32_t last_report_peak_limited = 0;
    uint32_t last_report_attenuated = 0;
    uint32_t last_report_tx_zeros = 0;
    uint32_t last_report_tx_ok = 0;
    float aec_rms = 0.0f;
    /* Persistent HPF state across frames; calculate coefficient once. */
    const float hpf_alpha = expf(-2.0f * 3.14159265358979323846f *
                                  C818_HPF_CUTOFF_HZ / (float)SAMPLE_RATE_HZ);
    float hpf_prev_in = 0.0f, hpf_prev_out = 0.0f;



    /* Dedicated TX task is already streaming silence while speaker is muted. */
    for (int k = 0; k < 6; k++) {
        if (esp_codec_dev_read(s_mic, s_pcm_rx, io_bytes) != 0) {
            c8_muted("RX warmup failed"); return;
        }
    }
    ESP_LOGW(TAG, "C8.21 FIXED output gain=%.1fx, limiter ceiling=%.0f, volume=%d/100; overload mute retained.",
             (double)C810_MAX_GAIN, (double)C810_TARGET_PEAK16, SPEAKER_VOLUME);
    ESP_LOGI(TAG, "C8.21 AFS=%s, harmonic-aware single notch (300-3000Hz), ~1s stable detection; no AGC",
             C821_AFS_ENABLE ? "ON" : "OFF");
    ESP_LOGI(TAG, "C8.21 voice HPF=%s cutoff=%.0fHz; AEC NLP=%s; no AGC/noise gate",
             C818_HPF_ENABLE ? "ON" : "OFF", (double)C818_HPF_CUTOFF_HZ, C821_AEC_NLP_NORMAL ? "NORMAL" : "AGGR");
    while (C8_MAX_SECONDS == 0 || esp_timer_get_time() - begun < (int64_t)C8_MAX_SECONDS * 1000000) {
        if (s_tx_stop || s_tx_fail != 0) { c8_muted("TX feeder fault"); return; }
        int read_rc = esp_codec_dev_read(s_mic, s_pcm_rx, io_bytes);
        if (read_rc != 0) {
            ESP_LOGE(TAG, "MIC read rc=%d", read_rc);
            if (++errors >= C8_MAX_IO_ERRORS) { c8_muted("RX failures"); return; }
            continue;
        }
        errors = 0;
        uint32_t mic_peak = 0, aec_peak = 0, out_peak = 0;
        double energy = 0;
        for (int i = 0; i < frame; ++i) {
            const int32_t a = s_pcm_rx[2*i] >> 16;
            const int32_t b = s_pcm_rx[2*i+1] >> 16;
            const int32_t mono = b; /* MIC2: higher energy confirmed by C8.7 */
            s_aec_mic[i] = (int16_t)c8_clamp(mono, 32767);
            const int32_t abs_mono = (mono < 0) ? -mono : mono;
            if ((uint32_t)abs_mono > mic_peak) mic_peak = (uint32_t)abs_mono;
            energy += (double)mono * mono;
        }
        last_rms = sqrt(energy / frame);
        /* Snapshot the PCM block most recently submitted by the TX feeder. */
        portENTER_CRITICAL(&s_tx_ref_mux);
        memcpy(s_aec_ref, s_tx_last_ref, ref_bytes);
        portEXIT_CRITICAL(&s_tx_ref_mux);
        /* AEC processing and output guards are unchanged from C8.4. */
        aec_process(s_aec, s_aec_mic, s_aec_ref, s_aec_out);
        if (!c81_check_guards()) { c8_muted("guard overwrite by AEC or I2S"); return; }
        /* Keep AEC output peak separate from the post-limiter DAC peak.
         * An all-zero or tiny AEC output during speech is now observable. */
        double aec_energy = 0.0;
        for (int i = 0; i < frame; ++i) {
            int32_t sample = s_aec_out[i];
            uint32_t magnitude = (uint32_t)(sample < 0 ? -sample : sample);
            if (magnitude > aec_peak) aec_peak = magnitude;
            aec_energy += (double)sample * (double)sample;
        }
        aec_rms = (float)sqrt(aec_energy / (double)frame);

        /* C8.21: post-AEC low-frequency cleanup. Filter runs before limiter
         * peak computation so aec_peak and output gain reflect actual PCM.
         * AEC input and acoustic reference are NOT altered here. */
#if C818_HPF_ENABLE
        aec_peak = 0;
        aec_energy = 0.0;
        for (int i = 0; i < frame; ++i) {
            const float in = (float)s_aec_out[i];
            const float filtered = hpf_alpha * (hpf_prev_out + in - hpf_prev_in);
            hpf_prev_in = in;
            hpf_prev_out = filtered;
            const int32_t v = c8_clamp((int32_t)filtered, 32767);
            s_aec_out[i] = (int16_t)v;
            const uint32_t mag = (uint32_t)(v < 0 ? -v : v);
            if (mag > aec_peak) aec_peak = mag;
            aec_energy += (double)v * (double)v;
        }
        aec_rms = (float)sqrt(aec_energy / (double)frame);
#endif
        /* Detect from un-notched signal, then apply a narrow tonal notch only
         * if a stable feedback-like frequency persisted across scans. */
        c821_afs_detect(s_aec_out, frame, block);
        c821_afs_process(s_aec_out, frame);
        if (s_afs.engaged || s_afs.wet > 0.0f) {
            aec_peak = 0;
            aec_energy = 0.0;
            for (int i=0; i<frame; ++i) {
                int32_t v=s_aec_out[i];
                uint32_t mag=(uint32_t)(v<0?-v:v);
                if (mag>aec_peak) aec_peak=mag;
                aec_energy+=(double)v*v;
            }
            aec_rms=(float)sqrt(aec_energy/(double)frame);
        }

        /* C8.21 fidelity baseline: NO AGC, NO speech-triggered noise gate and
         * NO RMS ducking. Constant gain preserves the singer's dynamics.
         * Rare overload frames may be attenuated uniformly to avoid PCM clip.
         * This is NOT an acoustic feedback suppressor. */
        /* C8.21 peak safety limiter: stable 8x nominal, only attenuate
         * when the block would clip the target ceiling. Release gain at a
         * controlled rate rather than jumping straight back to 8x every
         * 32 ms. No automatic gain increase above the singer's fixed 8x.
         * A frame boundary can still cause an abrupt ATTACK under severe
         * overload; this is a protective limiter, not studio mastering. */
        prior_gain = last_gain;
        const float safe_gain = aec_peak > 0
            ? fminf(C810_MAX_GAIN, C810_TARGET_PEAK16 / (float)aec_peak)
            : C810_MAX_GAIN;
        if (safe_gain < last_gain) {
            last_gain = safe_gain; /* attack immediately to protect ceiling */
        } else {
            last_gain = fminf(safe_gain, last_gain + C818_LIMITER_RELEASE_STEP);
        }
        if ((float)aec_peak * C810_MAX_GAIN > C810_TARGET_PEAK16) {
            ++peak_limited_blocks;
        }
        if (last_gain < C810_MAX_GAIN - 0.001f) ++limiter_attenuated_blocks;

        for (int i = 0; i < frame; ++i) {
            /* Use signed floating-point scaling. */
            const float scaled = (float)s_aec_out[i] * last_gain;
            int32_t y = (int32_t)scaled;
            y = c8_clamp(y, C8_OUTPUT_PEAK16);
            /* IMPORTANT: block is uint32_t. Never multiply a negative signed PCM
             * sample by (block + 1) without explicitly converting to signed.
             * In C8.2, unsigned promotion converted a negative sample to a huge
             * positive number (e.g. 0x06666666 == 107374182 on frame zero).
             * Signed 64-bit arithmetic preserves the negative sample correctly. */
            if (block < C8_START_FADE_BLOCKS) {
                const int64_t fade_num = (int64_t)y * ((int64_t)block + 1);
                y = (int32_t)(fade_num / (int64_t)C8_START_FADE_BLOCKS);
            }
            int32_t a = y < 0 ? -y : y;
            if ((uint32_t)a > out_peak) out_peak = (uint32_t)a;
            s_ref_previous[i] = (int16_t)y; /* queued DAC reference */
            const int32_t aligned = y * 65536;
            s_pcm_tx[2*i] = aligned;
            s_pcm_tx[2*i+1] = aligned;
        }
        if (!c81_check_guards()) { c8_muted("guard overwrite during PCM conversion"); return; }
        /* out_peak must never exceed C8_OUTPUT_PEAK16 after limiter; if it is, state was
         * corrupted and we must NOT unmute or play anything. */
        if (out_peak > C8_OUTPUT_PEAK16) {
            ESP_LOGE(TAG, "C8.21 INVALID OUTPEAK=%lu; limit=%d; possible memory corruption",
                     (unsigned long)out_peak, C8_OUTPUT_PEAK16);
            c8_muted("impossible outpeak / memory corruption"); return;
        }
        /* C8.21 safety logic: don't confuse ordinary speech with howling.
         * Long-term RMS and critical overload are monitored separately.
         * Each count represents one 32 ms AEC frame. */
        if (last_rms >= C812_HIGH_MIC_RMS16) ++high_rms_frames;
        else high_rms_frames = 0;
        if (last_rms >= C812_CRITICAL_MIC_RMS16 ||
            mic_peak >= C812_CRITICAL_MIC_PEAK16) ++critical_frames;
        else critical_frames = 0;
        if (!overload_muted && (critical_frames >= C812_CRITICAL_FRAMES ||
                                high_rms_frames >= C812_HIGH_RMS_FRAMES)) {
            /* Hard mute FIRST, and forbid feeder from playing frames already
             * in its queue. Never allow high-level PCM to resume immediately. */
            s_tx_audio_allowed = false;
            if (esp_codec_dev_set_out_mute(s_speaker, true) != 0) {
                c8_muted("hardware mute failed during overload"); return;
            }
            const int64_t trip_now = esp_timer_get_time();
            if (trip_window_start == 0 ||
                trip_now - trip_window_start > C812_TRIP_WINDOW_US) {
                trip_window_start = trip_now;
                recovery_count = 0;
            }
            ++recovery_count;
            ESP_LOGE(TAG, "C8.21 OVERLOAD MUTED micpeak=%lu micRMS=%.1f outpeak=%lu event=%u/%u",
                     (unsigned long)mic_peak, last_rms, (unsigned long)out_peak,
                     recovery_count, C812_MAX_TRIPS_WINDOW);
            if (recovery_count >= C812_MAX_TRIPS_WINDOW) {
                c8_muted("repeated acoustic overload in 30s"); return;
            }
            overload_muted = true;
            started = false;
            safe_preflight = 0;
            quiet_frames = 0;
            muted_frames = 0;
            high_rms_frames = 0;
            critical_frames = 0;
            memset(s_ref_previous, 0, ref_bytes);
            s_afs.engaged=false; s_afs.stable_count=0; s_afs.candidate_bin=-1; s_afs.candidate_hz=0.0f;
            /* Do not queue this dangerous frame. */
            continue;
        }
        if (overload_muted) {
            ++muted_frames;
            /* The TX feeder writes silence and clears AEC reference here. */
            if (last_rms < C812_RECOVERY_QUIET_RMS16 &&
                mic_peak < C812_RECOVERY_QUIET_PEAK16) {
                if (quiet_frames < C812_RECOVERY_QUIET_FRAMES) ++quiet_frames;
            } else {
                quiet_frames = 0;
            }
            if (muted_frames < C812_MIN_MUTED_FRAMES ||
                quiet_frames < C812_RECOVERY_QUIET_FRAMES) {
                if (muted_frames == 1 || muted_frames % 64 == 0) {
                    ESP_LOGW(TAG, "C8.21 MUTED COOLDOWN frames=%u quiet=%u/%u rms=%.1f peak=%lu",
                             muted_frames, quiet_frames, C812_RECOVERY_QUIET_FRAMES,
                             last_rms, (unsigned long)mic_peak);
                }
                continue;
            }
            ESP_LOGW(TAG, "C8.21 QUIET RECOVERY: MIC stable; restarting muted AEC preflight");
            overload_muted = false;
            high_rms_frames = 0;
            critical_frames = 0;
            safe_preflight = 0;
            started = false;
            memset(s_ref_previous, 0, ref_bytes);
            continue;
        }
        /* Keep ES8311 muted while 10 AEC frames are verified (~0.32 seconds).
         * During this period reference MUST stay zero, matching muted DAC. */
        if (!started && ++safe_preflight < C81_AEC_MUTED_PREFLIGHT_BLOCKS) {
            memset(s_ref_previous, 0, ref_bytes);
            if (safe_preflight == 1 || (safe_preflight % 20) == 0) {
                ESP_LOGI(TAG, "C8.21 MUTED AEC PREFLIGHT %u/%u mic=%lu out=%lu stack_free=%u",
                         safe_preflight, C81_AEC_MUTED_PREFLIGHT_BLOCKS,
                         (unsigned long)mic_peak, (unsigned long)out_peak,
                         (unsigned)uxTaskGetStackHighWaterMark(NULL));
            }
            continue;
        }
        if (!started) {
            /* Gate stays shut until the DAC is unmuted successfully. */
            if (esp_codec_dev_set_out_mute(s_speaker, false) != 0) {
                c8_muted("unmute failure"); return;
            }
            s_tx_audio_allowed = true;
            ESP_LOGI(TAG, "C8.21 SPEAKER ON (CONTROLLED LEVEL) | guarded AEC FD");
            started = true;
        }
        if (s_tx_stop || !s_tx_active || s_tx_fail != 0) {
            c8_muted("TX feeder stopped or failed"); return;
        }
        /* Queue decoded output to the dedicated TX DMA task; do not block
         * this RX/AEC task on a full audio TX write. */
        memcpy(queue_item.pcm, s_pcm_tx, io_bytes);
        memcpy(queue_item.ref, s_ref_previous, ref_bytes);
        if (xQueueSend(s_tx_queue, &queue_item, pdMS_TO_TICKS(1)) != pdTRUE) {
            ++s_tx_qdrop;
        }
        ++block;
        if (mic_peak > max_mic) max_mic = mic_peak;
        if (aec_peak > max_aec) max_aec = aec_peak;
        if (out_peak > max_out) max_out = out_peak;
        const int64_t now = esp_timer_get_time();
        if (now - log_at >= (int64_t)C8_REPORT_EVERY_MS * 1000) {
            ESP_LOGI(TAG, "C8.21 LIVE blocks=%lu MICpeak=%lu AECpeak=%lu OUTpeak=%lu rms=%.1f AEC=FD RXerr=0 TXerr=0",
                     (unsigned long)block, (unsigned long)max_mic, (unsigned long)max_aec, (unsigned long)max_out, last_rms);
            ESP_LOGI(TAG, "C8.21 TX feeder: ok=%lu silence=%lu dropped=%lu errors=%lu queued=%u",
                     (unsigned long)s_tx_ok, (unsigned long)s_tx_zeros,
                     (unsigned long)s_tx_qdrop, (unsigned long)s_tx_fail,
                     (unsigned)uxQueueMessagesWaiting(s_tx_queue));
            ESP_LOGI(TAG, "C8.21 limiter: gain=%.2fx prior=%.2fx peak_limited=%lu attenuated=%lu ceiling=%.0f release=%.2f/frame",
                     (double)last_gain, (double)prior_gain,
                     (unsigned long)peak_limited_blocks,
                     (unsigned long)limiter_attenuated_blocks,
                     (double)C810_TARGET_PEAK16,
                     (double)C818_LIMITER_RELEASE_STEP);
            ESP_LOGI(TAG, "C8.21 WINDOW 1s: limiter_peak=%lu limiter_attenuated=%lu tx_audio=%lu tx_silence=%lu (cumulative figures above)",
                     (unsigned long)(peak_limited_blocks-last_report_peak_limited),
                     (unsigned long)(limiter_attenuated_blocks-last_report_attenuated),
                     (unsigned long)(s_tx_ok-last_report_tx_ok),
                     (unsigned long)(s_tx_zeros-last_report_tx_zeros));
            last_report_peak_limited=peak_limited_blocks;
            last_report_attenuated=limiter_attenuated_blocks;
            last_report_tx_ok=s_tx_ok;
            last_report_tx_zeros=s_tx_zeros;
            ESP_LOGI(TAG, "C8.21 AFS: notch=%s freq=%.1fHz wet=%.2f stable=%u activations=%u",
                     s_afs.engaged ? "ON" : "OFF", (double)s_afs.freq_hz,
                     (double)s_afs.wet, s_afs.stable_count, s_afs.activations);
            ESP_LOGI(TAG, "C8.21 AFS analysis: detected=%.1fHz harmonic_ratio=%.3f harmonic_rejects=%u candidate=%.1fHz",
                     (double)s_afs.detected_hz, (double)s_afs.harmonic_ratio,
                     s_afs.harmonic_rejects, (double)s_afs.candidate_hz);
            ESP_LOGI(TAG, "C8.21 nominal gain=%.2fx current limiter gain=%.2fx aecRMS=%.1f",
                     (double)C810_MAX_GAIN, (double)last_gain,
                     (double)aec_rms);
            max_mic = max_aec = max_out = 0;
            log_at = now;
        }
    }
    c8_muted("configured runtime limit reached");
}


/* C8.21 removes the six-second record/replay phase. MIC2 was confirmed
 * stronger in the C8.7 capture log. Audio is streamed immediately after
 * bounded codec warmup and 10 muted AEC preflight frames. */

static void karaoke_audio_task(void *arg)
{
    (void)arg;
    ESP_LOGI(TAG, "===== SATURNVEX KARAOKE C8.21 LIVE | ES7210 -> FD AEC -> ES8311 =====");
    ESP_LOGI(TAG, "I2C SCL1 SDA2; I2S MCLK47 BCLK14 WS13 TX21 RX48, 16kHz/32bit/stereo");
    esp_err_t err = setup_bus();
    if (err != ESP_OK) { ESP_LOGE(TAG,"I2C bus %s",esp_err_to_name(err)); goto done; }
    if (i2c_master_probe(s_bus, ES7210_ADDR, 100) != ESP_OK ||
        i2c_master_probe(s_bus, ES8311_ADDR, 100) != ESP_OK) {
        ESP_LOGE(TAG,"I2C codec probe failed"); goto done;
    }
    if ((err=setup_i2s_full_duplex()) != ESP_OK) goto done;
    if ((err=setup_speaker()) != ESP_OK) goto done;
    if ((err=setup_mic()) != ESP_OK) goto done;
    ESP_LOGI(TAG, "C8.21 LIVE ONLY: MIC2 selected, no recording/replay delay");
    if ((err=c8_init_aec()) != ESP_OK) goto done;
    if ((err=c85_start_tx()) != ESP_OK) {
        ESP_LOGE(TAG, "C8.21 TX task startup failed: %s", esp_err_to_name(err));
        goto done;
    }
    ESP_LOGI(TAG, "C8.21 Dedicated TX task started on CPU0; RX/AEC remains on CPU1");
    c8_stream();
done:
    s_tx_audio_allowed = false;
    s_tx_stop = true;
    if (s_speaker) esp_codec_dev_set_out_mute(s_speaker, true);
    /* Do not free TX queue/ref before the feeder has finished using them. */
    for (int i = 0; i < 100 && s_tx_active; ++i) vTaskDelay(pdMS_TO_TICKS(10));
    if (s_tx_active) {
        ESP_LOGE(TAG, "TX task did not exit; retaining shared buffers for safety");
    } else {
        if (s_tx_queue) vQueueDelete(s_tx_queue);
        free(s_tx_last_ref);
    }
    if (s_aec) aec_destroy(s_aec);
    free(s_aec_mic); free(s_aec_ref); free(s_aec_out); free(s_ref_previous);
    free(s_pcm_rx); free(s_pcm_tx);
    ESP_LOGW(TAG,"C8 task exited, speaker muted");
    vTaskDelete(NULL);
}

void app_main(void)
{
    /* Separate task prevents C5 stack overflow; do not put PCM on main stack. */
    BaseType_t ok = xTaskCreatePinnedToCore(karaoke_audio_task, "svx_audio_aec", 16384,
                                            NULL, 5, NULL, 1);
    if (ok != pdPASS) ESP_LOGE(TAG, "Failed creating audio/AEC task");
}
