# Real-Time Karaoke Audio with AEC

**Project:** `SVX_ESP32S3_Karaoke_C8_AEC_FD` · **Board:** `SVX-ESP32-S3-001` · **MCU:** ESP32-S3 · **Framework:** ESP-IDF v6.1

Low-latency live microphone-to-speaker audio (application revision C8.21). Audio from the ES7210 ADC is processed on the ESP32-S3 with Espressif ESP-SR acoustic echo cancellation and played through the ES8311 DAC and the NS4150 speaker amplifier.

## Connections

| Signal | ESP32-S3 / setting |
|---|---|
| I²C SCL / SDA | GPIO1 / GPIO2 (ES8311 0x18, ES7210 0x40) |
| I2S MCLK / BCLK / WS | GPIO47 / GPIO14 / GPIO13 (shared, full duplex) |
| I2S TX (to ES8311) / RX (from ES7210) | GPIO21 / GPIO48 |
| NS4150 amplifier | Enabled by board hardware |

## Signal path

MIC2 → mono PCM16 → ESP-SR AEC (`AEC_MODE_FD_LOW_COST`, 16 kHz) → optional 70 Hz high-pass → adaptive feedback notch → fixed 8× gain and peak limiter → ES8311 (volume 85/100) → speaker. The speaker is muted automatically on sustained acoustic overload.

PSRAM must be enabled (octal, 80 MHz in `sdkconfig.defaults`). Echo cancellation and feedback suppression depend on the speaker / microphone placement and the room; start at a low listening level and keep the speaker away from the microphones.

## Build and flash

Open this folder (the one containing `CMakeLists.txt`) in VS Code with the ESP-IDF extension, then open an **ESP-IDF v6.1 terminal** and run:

```powershell
Remove-Item Env:IDF_TARGET -ErrorAction SilentlyContinue
idf.py set-target esp32s3
idf.py build
idf.py -p COM_PORT -b 115200 flash monitor
```

Replace `COM_PORT` with the native USB Serial/JTAG port of the board (for example `COM10`). Exit the monitor with `Ctrl+]`. The first build needs Internet access: the ESP-IDF Component Manager downloads `esp_codec_dev` 1.5.1 and `esp-sr` 2.5.0.

Keep the complete project (top-level `CMakeLists.txt`, `main/idf_component.yml`, `sdkconfig.defaults`, `partitions.csv`); replacing only `main.c` in another project will not build.

Full feature description, telemetry and limits: see the PDF guide.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex source and project files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
