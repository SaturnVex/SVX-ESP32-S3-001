/*
 * SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
 *
 * Project : SVX_ESP32S3_WiFi_Test
 * File    : main/main.c
 * Board   : SVX-ESP32-S3-001 (ESP32-S3), ESP-IDF v6.1
 * Purpose : Wi-Fi functional test. SoftAP (phone connects to the board) or
 *           Station (board joins a 2.4 GHz router), selected in menuconfig,
 *           with an HTTP server on port 80 serving GET / and GET /status.
 *
 * Evaluation firmware: plain HTTP without TLS or authentication.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_event.h"
#include "esp_wifi.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "esp_http_server.h"
#include "nvs_flash.h"
#include "sdkconfig.h"

static const char *TAG = "SVX_WIFI";
static volatile bool s_sta_connected = false;
static volatile uint32_t s_sta_retries = 0;
static volatile uint32_t s_requests = 0;
static volatile uint32_t s_ap_clients = 0;

static esp_err_t status_get_handler(httpd_req_t *req)
{
    char json[320];
    int rssi = 0;
    char ip[16] = "not-assigned";
    const char *mode;

#if CONFIG_SVX_WIFI_TEST_AP
    mode = "AP";
    esp_netif_t *netif = esp_netif_get_handle_from_ifkey("WIFI_AP_DEF");
#else
    mode = "STA";
    esp_netif_t *netif = esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
    wifi_ap_record_t ap = {0};
    if (esp_wifi_sta_get_ap_info(&ap) == ESP_OK) {
        rssi = (int)ap.rssi;
    }
#endif
    if (netif != NULL) {
        esp_netif_ip_info_t info;
        if (esp_netif_get_ip_info(netif, &info) == ESP_OK) {
            snprintf(ip, sizeof(ip), IPSTR, IP2STR(&info.ip));
        }
    }
    uint32_t count = ++s_requests;
    int len = snprintf(json, sizeof(json),
                       "{\"board\":\"SVX-ESP32-S3-001\",\"mode\":\"%s\","
                       "\"ip\":\"%s\",\"station_connected\":%s,"
                       "\"rssi_dbm\":%d,\"ap_clients\":%" PRIu32 ","
                       "\"requests\":%" PRIu32 ",\"uptime_ms\":%" PRIu64 "}\n",
                       mode, ip, s_sta_connected ? "true" : "false", rssi,
                       s_ap_clients, count, (uint64_t)(esp_timer_get_time() / 1000));
    if (len < 0 || len >= (int)sizeof(json)) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Response formatting failure");
    }
    httpd_resp_set_type(req, "application/json");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    ESP_LOGI(TAG, "HTTP GET /status count=%" PRIu32, count);
    return httpd_resp_send(req, json, HTTPD_RESP_USE_STRLEN);
}

static esp_err_t root_get_handler(httpd_req_t *req)
{
    static const char page[] =
        "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>SaturnVex Wi-Fi Test</title></head><body>"
        "<h2>SVX-ESP32-S3-001</h2><p>ESP32-S3 Wi-Fi functional test</p>"
        "<p><a href='/status'>View /status JSON</a></p>"
        "<p>Refresh /status to test data exchange with the board.</p></body></html>";
    httpd_resp_set_type(req, "text/html");
    return httpd_resp_send(req, page, HTTPD_RESP_USE_STRLEN);
}

static void start_http_server(void)
{
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    httpd_handle_t server = NULL;
    ESP_ERROR_CHECK(httpd_start(&server, &config));
    const httpd_uri_t root = {
        .uri = "/", .method = HTTP_GET, .handler = root_get_handler,
        .user_ctx = NULL
    };
    const httpd_uri_t status = {
        .uri = "/status", .method = HTTP_GET, .handler = status_get_handler,
        .user_ctx = NULL
    };
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &root));
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &status));
    ESP_LOGI(TAG, "HTTP server listening on TCP port 80");
}

static void wifi_event_handler(void *arg, esp_event_base_t base,
                               int32_t id, void *data)
{
    (void)arg;
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        ESP_LOGI(TAG, "STA start; connecting to router");
        esp_err_t err = esp_wifi_connect();
        if (err != ESP_OK) ESP_LOGE(TAG, "esp_wifi_connect failed: %s", esp_err_to_name(err));
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        s_sta_connected = false;
        s_sta_retries++;
        ESP_LOGW(TAG, "STA disconnected; retry=%" PRIu32, s_sta_retries);
        esp_err_t err = esp_wifi_connect();
        if (err != ESP_OK) ESP_LOGE(TAG, "esp_wifi_connect failed: %s", esp_err_to_name(err));
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        const ip_event_got_ip_t *event = (const ip_event_got_ip_t *)data;
        s_sta_connected = true;
        s_sta_retries = 0;
        ESP_LOGI(TAG, "STA connected; IP=" IPSTR " gateway=" IPSTR,
                 IP2STR(&event->ip_info.ip), IP2STR(&event->ip_info.gw));
        ESP_LOGI(TAG, "Open http://" IPSTR "/status from a device on the same LAN",
                 IP2STR(&event->ip_info.ip));
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STACONNECTED) {
        s_ap_clients++;
        ESP_LOGI(TAG, "SoftAP: phone joined; clients=%" PRIu32, s_ap_clients);
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STADISCONNECTED) {
        if (s_ap_clients > 0) s_ap_clients--;
        ESP_LOGI(TAG, "SoftAP: phone left; clients=%" PRIu32, s_ap_clients);
    }
}

static void wifi_initialize(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

#if CONFIG_SVX_WIFI_TEST_AP
    esp_netif_t *netif = esp_netif_create_default_wifi_ap();
#else
    esp_netif_t *netif = esp_netif_create_default_wifi_sta();
#endif
    if (netif == NULL) {
        ESP_LOGE(TAG, "esp_netif_create_default_wifi failed");
        abort();
    }

    wifi_init_config_t init = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                               &wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP,
                                               &wifi_event_handler, NULL));

#if CONFIG_SVX_WIFI_TEST_AP
    const char *ssid = CONFIG_SVX_WIFI_AP_SSID;
    const char *password = CONFIG_SVX_WIFI_AP_PASSWORD;
    size_t ssid_len = strlen(ssid);
    size_t pass_len = strlen(password);
    if (ssid_len == 0 || ssid_len > 32 || pass_len < 8 || pass_len > 63) {
        ESP_LOGE(TAG, "Invalid SoftAP SSID/password length (SSID 1-32, password 8-63)");
        abort();
    }
    wifi_config_t cfg = {0};
    memcpy(cfg.ap.ssid, ssid, ssid_len);
    cfg.ap.ssid_len = (uint8_t)ssid_len;
    memcpy(cfg.ap.password, password, pass_len);
    cfg.ap.channel = 1;
    cfg.ap.max_connection = 4;
    cfg.ap.authmode = WIFI_AUTH_WPA2_PSK;
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &cfg));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(TAG, "SoftAP SSID: %s", ssid);
    ESP_LOGI(TAG, "Connect a phone to Wi-Fi and open http://192.168.4.1/status");
#else
    const char *ssid = CONFIG_SVX_WIFI_STA_SSID;
    const char *password = CONFIG_SVX_WIFI_STA_PASSWORD;
    if (ssid[0] == '\0') {
        ESP_LOGE(TAG, "Set router SSID under SaturnVex Wi-Fi Test Configuration");
        abort();
    }
    if (strlen(ssid) > 32 || strlen(password) > 63) {
        ESP_LOGE(TAG, "Invalid router SSID/password length");
        abort();
    }
    wifi_config_t cfg = {0};
    memcpy(cfg.sta.ssid, ssid, strlen(ssid));
    memcpy(cfg.sta.password, password, strlen(password));
    cfg.sta.threshold.authmode = WIFI_AUTH_OPEN;
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &cfg));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(TAG, "Station mode; router SSID: %s", ssid);
#endif
}

void app_main(void)
{
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);
    ESP_LOGI(TAG, "SaturnVex Wi-Fi Test boot | SVX-ESP32-S3-001 | MCU ESP32-S3");
    wifi_initialize();
    start_http_server();
    while (true) {
        ESP_LOGI(TAG, "Heartbeat uptime=%" PRIu64 " s, HTTP requests=%" PRIu32,
                 (uint64_t)(esp_timer_get_time() / 1000000), s_requests);
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
}
