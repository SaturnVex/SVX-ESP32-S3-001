# Wi-Fi AP / STA HTTP Test

**Project:** `SVX_ESP32S3_WiFi_Test` · **Board:** `SVX-ESP32-S3-001` · **MCU:** ESP32-S3 · **Framework:** ESP-IDF v6.1

Wi-Fi functional test with an HTTP server on TCP port 80. The mode is selected at build time in menuconfig:

| Mode | Network | Board address |
|---|---|---|
| SoftAP (default) | Phone connects to `SaturnVex-S3-WiFi`, WPA2 password `SVXtest1234`, channel 1, up to 4 clients | `192.168.4.1` |
| Station | Board joins a 2.4 GHz router (SSID and password entered in menuconfig) | DHCP address printed in the monitor |

| Endpoint | Response |
|---|---|
| `GET /` | HTML status page |
| `GET /status` | JSON: `board`, `mode`, `ip`, `station_connected`, `rssi_dbm`, `ap_clients`, `requests`, `uptime_ms` |

## Build and flash

Open this folder (the one containing `CMakeLists.txt`) in VS Code with the ESP-IDF extension, then open an **ESP-IDF v6.1 terminal** and run:

```powershell
Remove-Item Env:IDF_TARGET -ErrorAction SilentlyContinue
idf.py set-target esp32s3
idf.py menuconfig
idf.py build
idf.py -p COM_PORT -b 115200 flash monitor
```

In menuconfig open **SaturnVex Wi-Fi Test Configuration**, choose SoftAP or Station and, for Station, enter the router SSID and password. Replace `COM_PORT` with the native USB Serial/JTAG port of the board (for example `COM10`). Exit the monitor with `Ctrl+]`.

## Test procedure

- **SoftAP:** connect a phone to `SaturnVex-S3-WiFi` (stay connected if the phone reports "No Internet") and open `http://192.168.4.1/` and `http://192.168.4.1/status`.
- **Station:** read `STA connected; IP=...` in the monitor, then open `http://<BOARD_IP>/status` from a device on the same LAN, or run `curl.exe http://<BOARD_IP>/status`.

Refreshing `/status` increments the request counter. The HTTP service has no TLS or authentication; use it on a controlled test network.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex source and project files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
