/*
 * SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
 *
 * Project : SVX_ESP32S3_BMI270_UART_Test
 * File    : main/main.c
 * Board   : SVX-ESP32-S3-001 (ESP32-S3), ESP-IDF v6.1
 * Purpose : BMI270 IMU test. I2C0 (SCL GPIO1, SDA GPIO2, address 0x68), CHIP_ID
 *           check, accelerometer +/-2 g and gyroscope +/-2000 dps at 100 Hz ODR,
 *           polled every 100 ms and streamed as CSV on UART1 TX (GPIO43, 115200 8-N-1).
 *
 * GPIO44 is reserved for the BMI270 INT1 data-ready line (not used in this test).
 * Bosch BMI270 SensorAPI (components/bosch_bmi270) is Copyright Bosch Sensortec
 * GmbH, BSD-3-Clause, unmodified; see NOTICE.txt.
 */
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2c_master.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_timer.h"
#include "esp_rom_sys.h"
#include "bmi270.h"

#define PIN_IMU_SCL GPIO_NUM_1
#define PIN_IMU_SDA GPIO_NUM_2
#define PIN_UART_TX GPIO_NUM_43
#define PIN_IMU_INT1 GPIO_NUM_44 /* Reserved for future BMI270 data-ready ISR */
#define UART_PORT UART_NUM_1 /* TX-only; USB Serial/JTAG used for diagnostics */
#define UART_BAUD 115200
#define I2C_CLOCK_HZ 100000
#define TIMEOUT_MS 3000
#define SAMPLE_PERIOD_MS 100
#define BMI270_EXPECTED_CHIP_ID 0x24
#define BMI270_I2C_ADDR 0x68
#define GRAVITY 9.80665f

static const char *TAG = "SVX_BMI270";
static i2c_master_bus_handle_t s_bus;
static i2c_master_dev_handle_t s_imu;


static void uart_line(const char *line)
{
    uart_write_bytes(UART_PORT, line, strlen(line));
}

static int8_t bus_read(uint8_t reg, uint8_t *data, uint32_t len, void *intf_ptr)
{
    (void)intf_ptr;
    if (len == 0 || len > 512) return BMI2_E_COM_FAIL;
    return (i2c_master_transmit_receive(s_imu, &reg, 1, data, (size_t)len, TIMEOUT_MS) == ESP_OK)
               ? BMI2_INTF_RET_SUCCESS : BMI2_E_COM_FAIL;
}

static int8_t bus_write(uint8_t reg, const uint8_t *data, uint32_t len, void *intf_ptr)
{
    (void)intf_ptr;
    if (len > 512) return BMI2_E_COM_FAIL;
    uint8_t payload[513];
    payload[0] = reg;
    if (len) memcpy(payload + 1, data, (size_t)len);
    return (i2c_master_transmit(s_imu, payload, (size_t)len + 1, TIMEOUT_MS) == ESP_OK)
               ? BMI2_INTF_RET_SUCCESS : BMI2_E_COM_FAIL;
}

static void delay_us(uint32_t period, void *intf_ptr)
{
    (void)intf_ptr;
    /* Bosch sensor API may request sub-ms waits during configuration loading. */
    if (period >= 1000) {
        uint32_t ms = (period + 999) / 1000;
        vTaskDelay(pdMS_TO_TICKS(ms) > 0 ? pdMS_TO_TICKS(ms) : 1);
    } else {
        esp_rom_delay_us(period);
    }
}

static void fail(const char *msg, int error)
{
    ESP_LOGE(TAG, "%s: %d", msg, error);
    char out[120];
    snprintf(out, sizeof(out), "ERROR,%s,%d\r\n", msg, error);
    uart_line(out);
    while (1) vTaskDelay(pdMS_TO_TICKS(2000));
}

static void init_uart(void)
{
    const uart_config_t config = {
        .baud_rate = UART_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(uart_driver_install(UART_PORT, 256, 2048, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(UART_PORT, &config));
    ESP_ERROR_CHECK(uart_set_pin(UART_PORT, PIN_UART_TX, UART_PIN_NO_CHANGE,
                                  UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    /* UART1 RX is NOT routed to GPIO44. GPIO44 is reserved for BMI270 INT1. */
}

static void init_i2c(void)
{
    const i2c_master_bus_config_t bus_cfg = {
        .i2c_port = I2C_NUM_0,
        .sda_io_num = PIN_IMU_SDA,
        .scl_io_num = PIN_IMU_SCL,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    ESP_ERROR_CHECK(i2c_new_master_bus(&bus_cfg, &s_bus));
    /* BMI270 SDO is tied to GND on the board, so its 7-bit address is 0x68. */
    esp_err_t probe = i2c_master_probe(s_bus, BMI270_I2C_ADDR, 1000);
    ESP_LOGI(TAG, "I2C probe 0x%02X: %s", BMI270_I2C_ADDR, esp_err_to_name(probe));
    if (probe != ESP_OK) fail("BMI270 not found at I2C 0x68", probe);
    const i2c_device_config_t device_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = BMI270_I2C_ADDR,
        .scl_speed_hz = I2C_CLOCK_HZ,
    };
    ESP_ERROR_CHECK(i2c_master_bus_add_device(s_bus, &device_cfg, &s_imu));
    uint8_t chip = 0;
    if (bus_read(0x00, &chip, 1, NULL) != BMI2_INTF_RET_SUCCESS)
        fail("CHIP_ID read failed", -1);
    ESP_LOGI(TAG, "BMI270 I2C=0x%02X, CHIP_ID=0x%02X", BMI270_I2C_ADDR, chip);
    if (chip != BMI270_EXPECTED_CHIP_ID) fail("Unexpected BMI270 CHIP_ID", chip);
}

static void reserve_imu_int1_gpio(void)
{
    /* Polling test: GPIO44 is configured as an input only; no interrupt handler is installed. */
    const gpio_config_t cfg = {
        .pin_bit_mask = (1ULL << PIN_IMU_INT1),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&cfg));
    ESP_LOGI(TAG, "GPIO44 reserved as BMI270 INT1 input; polling mode active");
}

static void config_bmi270(struct bmi2_dev *bmi)
{
    int8_t ret = bmi270_init(bmi); /* Loads Bosch firmware/config blob (~8 KB) */
    if (ret != BMI2_OK) fail("bmi270_init", ret);
    struct bmi2_sens_config cfg[2] = {
        {.type = BMI2_ACCEL},
        {.type = BMI2_GYRO},
    };
    ret = bmi2_get_sensor_config(cfg, 2, bmi);
    if (ret != BMI2_OK) fail("get_sensor_config", ret);
    cfg[0].cfg.acc.odr = BMI2_ACC_ODR_100HZ;
    cfg[0].cfg.acc.range = BMI2_ACC_RANGE_2G;
    cfg[0].cfg.acc.bwp = BMI2_ACC_NORMAL_AVG4;
    cfg[0].cfg.acc.filter_perf = BMI2_PERF_OPT_MODE;
    cfg[1].cfg.gyr.odr = BMI2_GYR_ODR_100HZ;
    cfg[1].cfg.gyr.range = BMI2_GYR_RANGE_2000;
    cfg[1].cfg.gyr.bwp = BMI2_GYR_NORMAL_MODE;
    cfg[1].cfg.gyr.noise_perf = BMI2_POWER_OPT_MODE;
    cfg[1].cfg.gyr.filter_perf = BMI2_PERF_OPT_MODE;
    ret = bmi2_set_sensor_config(cfg, 2, bmi);
    if (ret != BMI2_OK) fail("set_sensor_config", ret);
    const uint8_t sensors[] = {BMI2_ACCEL, BMI2_GYRO};
    ret = bmi270_sensor_enable(sensors, 2, bmi);
    if (ret != BMI2_OK) fail("sensor_enable", ret);
    ESP_LOGI(TAG, "Accel +/-2g, gyro +/-2000dps, ODR=100Hz, UART output=10Hz");
}

void app_main(void)
{
    ESP_LOGI(TAG, "SaturnVex BMI270 I2C to UART | SVX-ESP32-S3-001");
    init_uart();
    reserve_imu_int1_gpio();
    uart_line("BOOT,SVX-ESP32-S3-001,BMI270_TEST\r\n");
    init_i2c();
    struct bmi2_dev bmi = {0};
    bmi.intf = BMI2_I2C_INTF;
    bmi.read = bus_read;
    bmi.write = bus_write;
    bmi.delay_us = delay_us;
    bmi.intf_ptr = NULL;
    bmi.read_write_len = 32; /* Incremental Bosch firmware upload; 100 kHz I2C */
    config_bmi270(&bmi);
    uart_line("READY,BMI270,ACC_2G,GYR_2000DPS\r\n");
    uart_line("seq,uptime_ms,ax_mps2,ay_mps2,az_mps2,gx_dps,gy_dps,gz_dps\r\n");
    uint32_t seq = 0;
    while (1) {
        struct bmi2_sens_data sample = {0};
        int8_t r = bmi2_get_sensor_data(&sample, &bmi);
        if (r == BMI2_OK &&
            (sample.status & BMI2_DRDY_ACC) && (sample.status & BMI2_DRDY_GYR)) {
            /* 16-bit signed samples, +/-2g accel and +/-2000 deg/s gyro. */
            const float accel_scale = GRAVITY * 2.0f / 32768.0f;
            const float gyro_scale = 2000.0f / 32768.0f;
            char line[220];
            snprintf(line, sizeof(line), "%lu,%lld,%.4f,%.4f,%.4f,%.3f,%.3f,%.3f\r\n",
                     (unsigned long)++seq, (long long)(esp_timer_get_time()/1000),
                     sample.acc.x*accel_scale, sample.acc.y*accel_scale, sample.acc.z*accel_scale,
                     sample.gyr.x*gyro_scale, sample.gyr.y*gyro_scale, sample.gyr.z*gyro_scale);
            uart_line(line);
            if ((seq % 10) == 0) {
                ESP_LOGI(TAG, "seq=%lu A=(%.2f %.2f %.2f) m/s2, G=(%.2f %.2f %.2f) dps",
                         (unsigned long)seq, sample.acc.x*accel_scale,
                         sample.acc.y*accel_scale, sample.acc.z*accel_scale,
                         sample.gyr.x*gyro_scale, sample.gyr.y*gyro_scale, sample.gyr.z*gyro_scale);
            }
        } else if (r != BMI2_OK) {
            ESP_LOGW(TAG, "Sensor read error=%d", r);
        }
        vTaskDelay(pdMS_TO_TICKS(SAMPLE_PERIOD_MS));
    }
}
