# Bosch Sensortec BMI270 SensorAPI v2.86.1, bundled unmodified (BSD-3-Clause, see LICENSE).
idf_component_register(SRCS "bmi2.c" "bmi270.c" INCLUDE_DIRS ".")
