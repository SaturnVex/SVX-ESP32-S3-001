# BMI270 IMU UART Test

**Project:** `SVX_ESP32S3_BMI270_UART_Test` · **Board:** `SVX-ESP32-S3-001` · **MCU:** ESP32-S3 · **Framework:** ESP-IDF v6.1

Reads the Bosch **BMI270** 6-axis IMU over I²C with the official Bosch SensorAPI and streams accelerometer and gyroscope data as CSV on UART1. Diagnostic logs are printed on the native USB Serial/JTAG console.

## Connections

| Signal | ESP32-S3 | Notes |
|---|---|---|
| BMI270 SCL / SDA | GPIO1 / GPIO2 | I²C0, 100 kHz, 7-bit address 0x68 (SDO to GND) |
| BMI270 INT1 | GPIO44 | Input reserved; not used in this polling test |
| UART1 TX | GPIO43 | 115200 baud, 8-N-1, CSV output (TX only) |
| USB D− / D+ | GPIO19 / GPIO20 | Programming and diagnostic console |

Connect GPIO43 to the RX pin of a 3.3 V USB-UART adapter and connect the grounds. Do not connect the adapter TX to GPIO44.

## Firmware operation

- Probes 0x68, checks CHIP_ID = 0x24 and loads the Bosch BMI270 configuration.
- Accelerometer ±2 g, gyroscope ±2000 °/s, both at 100 Hz ODR; data are polled every 100 ms.
- UART1 prints a `BOOT` and a `READY` record, the header `seq,uptime_ms,ax_mps2,ay_mps2,az_mps2,gx_dps,gy_dps,gz_dps` and one CSV line per sample.

The Bosch BMI270 SensorAPI v2.86.1 is included unmodified in `components/bosch_bmi270/`; no download is required.

## Build and flash

Open this folder (the one containing `CMakeLists.txt`) in VS Code with the ESP-IDF extension, then open an **ESP-IDF v6.1 terminal** and run:

```powershell
Remove-Item Env:IDF_TARGET -ErrorAction SilentlyContinue
idf.py set-target esp32s3
idf.py build
idf.py -p COM_PORT -b 115200 flash monitor
```

Replace `COM_PORT` with the native USB Serial/JTAG port of the board (for example `COM10`). Exit the monitor with `Ctrl+]`.

## Expected result

At rest the acceleration magnitude is close to 9.81 m/s² and the gyroscope values are close to zero. Rotating or tilting the board changes the corresponding axes. See the PDF test guide for troubleshooting.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex source and project files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
