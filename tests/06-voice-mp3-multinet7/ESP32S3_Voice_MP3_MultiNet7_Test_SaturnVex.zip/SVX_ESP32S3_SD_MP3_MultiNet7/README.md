# Voice-Controlled SD MP3 Player (MultiNet7)

**Project:** `SVX_ESP32S3_SD_MP3_MultiNet7` · **Board:** `SVX-ESP32-S3-001` · **MCU:** ESP32-S3 · **Framework:** ESP-IDF v6.1

SD-card MP3 player with offline English voice commands (application revision v35). Playback runs concurrently with the ES7210 microphone path; Espressif AFE / VAD and **MultiNet7** recognise the commands on the device without Wi-Fi or cloud services.

## Commands

| Voice | Serial key | Action |
|---|---|---|
| NEXT | `N` | Next track, play immediately |
| BACK | `B` | Previous track, play immediately |
| ENTER | `P` | Start / resume playback |
| STOP | `S` | Stop playback |
| EXIT | `X` | Stop and select the first track |

Serial keys are typed in the ESP-IDF monitor followed by Enter; use them first to confirm SD card and speaker operation.

## Connections

| Signal | ESP32-S3 |
|---|---|
| SDMMC CLK / CMD / D0 | GPIO17 / GPIO8 / GPIO18 |
| I²C SCL / SDA | GPIO1 / GPIO2 |
| I2S MCLK / BCLK / WS | GPIO47 / GPIO14 / GPIO13 |
| I2S TX (to ES8311) / RX (from ES7210) | GPIO21 / GPIO48 |

## Notes

- Recursive MP3 discovery, up to 3000 tracks and 24 folder levels; the card is never written.
- A fixed 16 kHz full-duplex I2S clock is used; 44.1 / 48 kHz MP3 files are resampled to 16 kHz.
- FD_LOW_COST AEC with the playback reference cleans the microphone signal before AFE / MultiNet7.
- Requires octal PSRAM. `partitions.csv`: factory app 6 MB at 0x10000, speech model 8 MB at 0x610000.

## Build and flash

Open this folder (the one containing `CMakeLists.txt`) in VS Code with the ESP-IDF extension, then open an **ESP-IDF v6.1 terminal** and run:

```powershell
Remove-Item Env:IDF_TARGET -ErrorAction SilentlyContinue
idf.py set-target esp32s3
idf.py menuconfig
idf.py build
idf.py -p COM_PORT -b 115200 flash monitor
```

Replace `COM_PORT` with the native USB Serial/JTAG port of the board (for example `COM10`). Exit the monitor with `Ctrl+]`. In menuconfig select *ESP Speech Recognition → English Speech Commands Model → general english recognition (mn7_en)* (already selected in the supplied `sdkconfig`). The first build needs Internet access for the managed components `esp-sr` 2.6.1, `esp_codec_dev` 1.5.1 and `esp_audio_codec` 2.6.2. `flash` writes the application and the speech model partition.

Recognition accuracy depends on the speaker, the playback volume and the environment; music echo can cause false commands at high volume. See the PDF guide for configuration details and limits.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex source and project files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
