cmake_minimum_required(VERSION 3.16)
include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(SVX_ESP32S3_SD_MP3_MultiNet7)
# ESP-IDF v6.1 GCC preprocessor compatibility for esp_codec_dev 1.5.1:
if(TARGET __idf_espressif__esp_codec_dev)
    target_compile_options(__idf_espressif__esp_codec_dev PRIVATE "-include" "esp_idf_version.h")
endif()
# Build esp_lcd without optimisation (avoids a GCC 15.2 internal compiler error):
if(TARGET __idf_esp_lcd)
    target_compile_options(__idf_esp_lcd PRIVATE -O0)
endif()
