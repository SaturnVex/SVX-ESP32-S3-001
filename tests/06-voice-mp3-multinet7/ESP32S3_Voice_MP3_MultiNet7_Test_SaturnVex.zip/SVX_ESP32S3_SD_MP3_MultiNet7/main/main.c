/*
 * SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
 *
 * Project : SVX_ESP32S3_SD_MP3_MultiNet7
 * File    : main/main.c
 * Board   : SVX-ESP32-S3-001 (ESP32-S3), ESP-IDF v6.1
 * Purpose : Offline MultiNet7 English voice commands (NEXT, BACK, ENTER, EXIT, STOP)
 *           controlling a recursive SDMMC MP3 player (application revision v35).
 *
 * SD: CLK GPIO17, CMD GPIO8, D0 GPIO18. I2C: SDA GPIO2, SCL GPIO1.
 * I2S: MCLK47, BCLK14, WS13, TX21, RX48; ES7210 MIC1 and ES8311 -> NS4150.
 * One fixed 16 kHz / 16-bit stereo full-duplex I2S clock; MP3 audio is
 * resampled to 16 kHz. FD_LOW_COST AEC cleans the microphone signal before
 * AFE / MultiNet7.
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <sys/stat.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "esp_heap_caps.h"
#include "esp_vfs_fat.h"
#include "driver/sdmmc_host.h"
#include "sdmmc_cmd.h"
#include "driver/i2c_master.h"
#include "driver/i2s_std.h"
#include "esp_codec_dev.h"
#include "esp_codec_dev_defaults.h"
#include "es8311_codec.h"
#include "es7210_adc.h"
#include "esp_audio_simple_dec.h"
#include "esp_audio_simple_dec_default.h"
#include "esp_audio_dec_default.h"
#include "esp_aec.h"
#include "esp_afe_sr_iface.h"
#include "esp_afe_sr_models.h"
#include "esp_mn_iface.h"
#include "esp_mn_models.h"
#include "esp_mn_speech_commands.h"
#include "model_path.h"

#define TAG "SVX_VOICE_MP3"
#define SD_MOUNT "/sdcard"
#define FREQ_HZ 16000U
#define MP3_READ_BYTES 2048U
#define DECODE_BYTES 16384U
#define OUTPUT_FRAMES 1024U
#define MAX_TRACKS 3000U
#define MAX_SCAN_DEPTH 24U
#define MIN_SCORE_IDLE 0.20f  /* default idle command threshold */
#define MIN_SCORE_IDLE_NAV 0.14f /* idle NEXT/BACK threshold; VAD speech gate still required */
#define MIN_SCORE_PLAYING 0.35f  /* conservative for general commands during playback */
#define MIN_SCORE_STOP_PLAYING 0.13f /* STOP threshold during playback; minimum VAD length also required */
#define VAD_END_SILENCE_FRAMES 12U /* 384ms sustained silence closes utterance */
#define VAD_MAX_UTTERANCE_FRAMES 96U /* hard cap 3.072s for continuous VAD (music echo/noise) */
#define STOP_MIN_VAD_FRAMES 8U /* >=256ms of VAD speech */
#define AFE_MAX_INFLIGHT_FRAMES 4U /* bound feed lead over fetch; shed excess frames */
#define COMMAND_COOLDOWN_MS 1600U
#define MIC_GAIN_DB 37.5f
#define MIC_SOFT_GAIN 4 /* software microphone gain ahead of AEC / AFE */
#define SPEAKER_VOLUME 85  /* ES8311 output volume, 0-100 */
/* C8.21 karaoke AEC source: FD_LOW_COST, 16kHz, 1 microphone/1 playback ref.
 * Align AEC reference to acoustic echo by adjusting this integer (32ms steps).
 * 0: newest PCM submitted to DAC, 1: one frame older, etc.
 * AEC is not guaranteed to cancel loudspeaker bleed until delay is calibrated. */
#define AEC_FRAME_SAMPLES 512
#define AEC_REF_HISTORY 16U
#define AEC_REF_DELAY_FRAMES 2U
#define AEC_STATS_INTERVAL 100U
#define REF_STALE_MS 128U /* discard DAC reference not updated for >4 audio frames */

static i2c_master_bus_handle_t s_i2c;
static i2s_chan_handle_t s_tx, s_rx;
static esp_codec_dev_handle_t s_dac, s_mic;
static QueueHandle_t s_commands;
static SemaphoreHandle_t s_afe_feed_credits;
static volatile uint32_t s_afe_frames_dropped;
static volatile uint32_t s_afe_frames_fetched;
static char **s_tracks;
static size_t s_track_count;
static volatile bool s_reduce_playback;
static volatile bool s_voice_ready;
static volatile bool s_player_active;
static volatile bool s_dac_muted = true;
static int16_t s_pcm16_out[OUTPUT_FRAMES * 2U];
static uint8_t s_mp3_bytes[MP3_READ_BYTES];
static uint8_t s_decoded[DECODE_BYTES];
/* Playback PCM reference ring, each block corresponds to 32 ms of the final
 * 16kHz mono signal actually submitted to the ES8311. This uses a C8.21-style
 * 'recently submitted DAC reference' with configurable fixed delay. */
static portMUX_TYPE s_ref_mux = portMUX_INITIALIZER_UNLOCKED;
static int16_t s_ref_history[AEC_REF_HISTORY][AEC_FRAME_SAMPLES];
static uint32_t s_ref_blocks_written;
static TickType_t s_ref_last_write_tick;
static int16_t s_ref_accum[AEC_FRAME_SAMPLES];
static size_t s_ref_accum_count;
static volatile bool s_ref_active;
static uint32_t s_ref_underruns;

static void playback_ref_clear(void) {
    portENTER_CRITICAL(&s_ref_mux);
    s_ref_blocks_written = 0;
    s_ref_accum_count = 0;
    s_ref_active = false;
    portEXIT_CRITICAL(&s_ref_mux);
}

/* Called only after the final playback PCM has been constructed at 16 kHz,
 * before esp_codec_dev_write; only the frames actually handed to the DAC are
 * considered. One writer (player task), one reader (microphone task). */
static void playback_ref_push(const int16_t *stereo, size_t frames) {
    portENTER_CRITICAL(&s_ref_mux);
    s_ref_active = true;
    for (size_t i = 0; i < frames; ++i) {
        /* Stereo downmix matches speaker PCM for reference (mono output). */
        int32_t mixed = ((int32_t)stereo[2*i] + stereo[2*i+1]) / 2;
        s_ref_accum[s_ref_accum_count++] = (int16_t)mixed;
        if (s_ref_accum_count == AEC_FRAME_SAMPLES) {
            memcpy(s_ref_history[s_ref_blocks_written % AEC_REF_HISTORY],
                   s_ref_accum, sizeof(s_ref_accum));
            s_ref_blocks_written++;
            s_ref_last_write_tick = xTaskGetTickCount();
            s_ref_accum_count = 0;
        }
    }
    portEXIT_CRITICAL(&s_ref_mux);
}
static bool playback_ref_snapshot(int16_t *dst) {
    bool valid = false;
    portENTER_CRITICAL(&s_ref_mux);
    TickType_t now = xTaskGetTickCount();
    if (s_ref_active && !s_dac_muted && s_player_active &&
        s_ref_blocks_written > AEC_REF_DELAY_FRAMES &&
        (TickType_t)(now - s_ref_last_write_tick) <= pdMS_TO_TICKS(REF_STALE_MS)) {
        uint32_t idx = (s_ref_blocks_written - 1U - AEC_REF_DELAY_FRAMES) % AEC_REF_HISTORY;
        memcpy(dst, s_ref_history[idx], AEC_FRAME_SAMPLES * sizeof(int16_t));
        valid = true;
    } else {
        memset(dst, 0, AEC_FRAME_SAMPLES * sizeof(int16_t));
    }
    portEXIT_CRITICAL(&s_ref_mux);
    if (!valid) s_ref_underruns++;
    return valid;
}

typedef enum { CMD_NEXT=101, CMD_BACK=102, CMD_ENTER=103, CMD_EXIT=104, CMD_STOP=105 } voice_cmd_t;
typedef enum { PLAY_END, PLAY_NEXT, PLAY_BACK, PLAY_STOP, PLAY_EXIT, PLAY_ERROR } play_result_t;
static const char *cmd_name(int id) {
    switch (id) { case CMD_NEXT: return "NEXT"; case CMD_BACK: return "BACK";
        case CMD_ENTER: return "ENTER"; case CMD_EXIT: return "EXIT";
        case CMD_STOP: return "STOP"; default: return "UNKNOWN"; }
}
static int16_t sat16(int32_t x) {
    if (x > INT16_MAX) return INT16_MAX;
    if (x < INT16_MIN) return INT16_MIN;
    return (int16_t)x;
}
static esp_err_t mount_sd(void) {
    sdmmc_host_t host = SDMMC_HOST_DEFAULT();
    host.slot = SDMMC_HOST_SLOT_1;
    host.max_freq_khz = 10000;
    sdmmc_slot_config_t slot = SDMMC_SLOT_CONFIG_DEFAULT();
    slot.width = 1; slot.clk = GPIO_NUM_17; slot.cmd = GPIO_NUM_8;
    slot.d0 = GPIO_NUM_18; slot.flags |= SDMMC_SLOT_FLAG_INTERNAL_PULLUP;
    esp_vfs_fat_sdmmc_mount_config_t cfg = {
        .format_if_mount_failed = false, .max_files = 6, .allocation_unit_size = 16 * 1024
    };
    sdmmc_card_t *card = NULL;
    esp_err_t err = esp_vfs_fat_sdmmc_mount(SD_MOUNT, &host, &slot, &cfg, &card);
    if (err == ESP_OK) ESP_LOGI(TAG, "SD mounted FAT32; recursive MP3 scan; card is never formatted");
    return err;
}
static esp_err_t init_audio(void) {
    i2c_master_bus_config_t bus = {
        .i2c_port = I2C_NUM_0, .sda_io_num = GPIO_NUM_2, .scl_io_num = GPIO_NUM_1,
        .clk_source = I2C_CLK_SRC_DEFAULT, .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true
    };
    ESP_RETURN_ON_ERROR(i2c_new_master_bus(&bus, &s_i2c), TAG, "I2C");
    i2s_chan_config_t chan = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    chan.dma_desc_num = 8; chan.dma_frame_num = 256;
    ESP_RETURN_ON_ERROR(i2s_new_channel(&chan, &s_tx, &s_rx), TAG, "I2S");
    i2s_std_config_t std = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(FREQ_HZ),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = { .mclk = GPIO_NUM_47, .bclk = GPIO_NUM_14, .ws = GPIO_NUM_13,
                      .dout = GPIO_NUM_21, .din = GPIO_NUM_48 }
    };
    ESP_RETURN_ON_ERROR(i2s_channel_init_std_mode(s_tx, &std), TAG, "I2S TX");
    ESP_RETURN_ON_ERROR(i2s_channel_init_std_mode(s_rx, &std), TAG, "I2S RX");

    audio_codec_i2c_cfg_t dac_bus = {.addr = ES8311_CODEC_DEFAULT_ADDR, .bus_handle = s_i2c};
    const audio_codec_ctrl_if_t *dac_ctrl = audio_codec_new_i2c_ctrl(&dac_bus);
    const audio_codec_gpio_if_t *dac_gpio = audio_codec_new_gpio();
    audio_codec_i2s_cfg_t dac_i2s = {.port = I2S_NUM_0, .rx_handle = NULL, .tx_handle = s_tx};
    const audio_codec_data_if_t *dac_data = audio_codec_new_i2s_data(&dac_i2s);
    if (!dac_ctrl || !dac_gpio || !dac_data) return ESP_ERR_NO_MEM;
    es8311_codec_cfg_t dac_cfg = {
        .ctrl_if = dac_ctrl, .gpio_if = dac_gpio, .codec_mode = ESP_CODEC_DEV_WORK_MODE_DAC,
        .pa_pin = -1, .use_mclk = true, .master_mode = false
    };
    const audio_codec_if_t *dac_codec = es8311_codec_new(&dac_cfg);
    if (!dac_codec) return ESP_FAIL;
    esp_codec_dev_cfg_t dac_dev = {
        .codec_if = dac_codec, .data_if = dac_data, .dev_type = ESP_CODEC_DEV_TYPE_OUT
    };
    s_dac = esp_codec_dev_new(&dac_dev);
    if (!s_dac) return ESP_ERR_NO_MEM;
    esp_codec_dev_sample_info_t fmt = {.sample_rate = FREQ_HZ, .channel = 2, .bits_per_sample = 16};
    if (esp_codec_dev_open(s_dac, &fmt) != 0) return ESP_FAIL;
    if (esp_codec_dev_set_out_vol(s_dac, SPEAKER_VOLUME) != 0) return ESP_FAIL;
    if (esp_codec_dev_set_out_mute(s_dac, true) != 0) return ESP_FAIL;
    ESP_LOGI(TAG, "DAC initialized muted until playback starts");

    audio_codec_i2c_cfg_t mic_bus = {.addr = ES7210_CODEC_DEFAULT_ADDR, .bus_handle = s_i2c};
    const audio_codec_ctrl_if_t *mic_ctrl = audio_codec_new_i2c_ctrl(&mic_bus);
    audio_codec_i2s_cfg_t mic_i2s = {.port = I2S_NUM_0, .rx_handle = s_rx, .tx_handle = NULL};
    const audio_codec_data_if_t *mic_data = audio_codec_new_i2s_data(&mic_i2s);
    if (!mic_ctrl || !mic_data) return ESP_ERR_NO_MEM;
    es7210_codec_cfg_t mic_cfg = { .ctrl_if = mic_ctrl,
        .mic_selected = ES7210_SEL_MIC1 | ES7210_SEL_MIC2, .master_mode = false };
    const audio_codec_if_t *mic_codec = es7210_codec_new(&mic_cfg);
    if (!mic_codec) return ESP_FAIL;
    esp_codec_dev_cfg_t mic_dev = {
        .codec_if = mic_codec, .data_if = mic_data, .dev_type = ESP_CODEC_DEV_TYPE_IN
    };
    s_mic = esp_codec_dev_new(&mic_dev);
    if (!s_mic || esp_codec_dev_open(s_mic, &fmt) != 0) return ESP_FAIL;
    if (esp_codec_dev_set_in_gain(s_mic, MIC_GAIN_DB) != 0) return ESP_FAIL;
    ESP_LOGI(TAG, "ES7210 MIC1 + ES8311/NS4150 16kHz stereo16 full duplex; volume=%d", SPEAKER_VOLUME);
    return ESP_OK;
}

static int cmp_names(const void *a, const void *b) {
    const char *const *pa = a, *const *pb = b;
    return strcasecmp(*pa, *pb);
}
static bool is_mp3(const char *name) {
    const char *dot = strrchr(name, '.');
    return name[0] != '.' && dot && !strcasecmp(dot, ".mp3");
}
static bool add_track(const char *name) {
    if (s_track_count >= MAX_TRACKS) return false;
    char *copy = strdup(name);
    if (!copy) return false;
    s_tracks[s_track_count++] = copy;
    return true;
}
static void scan_tree(const char *folder, unsigned depth) {
    if (depth >= MAX_SCAN_DEPTH || s_track_count >= MAX_TRACKS) return;
    DIR *d = opendir(folder);
    if (!d) return;
    char **items = NULL; size_t count = 0, capacity = 0;
    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        if (ent->d_name[0] == '.') continue;
        if (count == capacity) {
            size_t cap = capacity ? capacity * 2 : 16;
            char **next = realloc(items, cap * sizeof(*next));
            if (!next) break;
            items = next; capacity = cap;
        }
        items[count] = strdup(ent->d_name);
        if (items[count]) count++;
    }
    closedir(d);
    qsort(items, count, sizeof(*items), cmp_names);
    for (size_t i = 0; i < count; ++i) {
        size_t len = strlen(folder) + strlen(items[i]) + 2U;
        char *path = malloc(len);
        if (path) {
            snprintf(path, len, "%s/%s", folder, items[i]);
            struct stat st;
            if (stat(path, &st) == 0) {
                if (S_ISDIR(st.st_mode)) scan_tree(path, depth + 1U);
                else if (S_ISREG(st.st_mode) && is_mp3(items[i])) {
                    if (!add_track(path)) ESP_LOGW(TAG, "Track capacity reached or OOM");
                }
            }
            free(path);
        }
        free(items[i]);
        if ((i & 15U) == 0U) vTaskDelay(1);
    }
    free(items);
}

/* AFE feeds PCM continuously. Voice results pass VAD, score, one-per-utterance,
 * cooldown and debug gates before entering the player command queue. */
static void voice_feed_task(void *arg) {
    const esp_afe_sr_iface_t *afe = ((void **)arg)[0];
    esp_afe_sr_data_t *data = ((void **)arg)[1];
    free(arg);
    const int feed_samples = afe->get_feed_chunksize(data);
    const int channels = afe->get_feed_channel_num(data);
    if (feed_samples != AEC_FRAME_SAMPLES || channels != 1) {
        ESP_LOGE(TAG, "AEC/AFE frame incompatible: %d samples, %d channel(s)", feed_samples, channels);
        vTaskDelete(NULL); return;
    }
    /* Derived directly from the stable Karaoke C8.21 AEC configuration.
     * Note: AEC mic/ref/out buffers must remain valid across aec_process. */
    aec_config_t aec_cfg = {
        .mic_num = 1, .ref_num = 1, .out_num = 1,
        .filter_length = 4, .sample_rate = FREQ_HZ,
        .caps = MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT,
        .mode = AEC_MODE_FD_LOW_COST, .nlp_level = AEC_NLP_LEVEL_NORMAL,
    };
    aec_handle_t *aec = aec_create_from_config(&aec_cfg);
    if (!aec) { ESP_LOGE(TAG, "C8.21 AEC create failed"); vTaskDelete(NULL); return; }
    if (aec_get_chunksize(aec) != AEC_FRAME_SAMPLES) {
        ESP_LOGE(TAG, "AEC chunk mismatch: %d", aec_get_chunksize(aec));
        aec_destroy(aec); vTaskDelete(NULL); return;
    }
    const size_t mono_bytes = AEC_FRAME_SAMPLES * sizeof(int16_t);
    int16_t *stereo = heap_caps_aligned_alloc(16, 2U * mono_bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    int16_t *mic = heap_caps_aligned_alloc(16, mono_bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    int16_t *ref = heap_caps_aligned_alloc(16, mono_bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    int16_t *clean = heap_caps_aligned_alloc(16, mono_bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (!stereo || !mic || !ref || !clean) {
        ESP_LOGE(TAG, "AEC I/O buffers OOM");
        free(stereo); free(mic); free(ref); free(clean);
        aec_destroy(aec); vTaskDelete(NULL); return;
    }
    ESP_LOGI(TAG, "C8.21 FD AEC ON: 16kHz frame=%d, ref_delay=%u x32ms, speaker=%d",
             AEC_FRAME_SAMPLES, AEC_REF_DELAY_FRAMES, SPEAKER_VOLUME);
    uint32_t frames = 0;
    uint32_t clipped_frames = 0;
    uint32_t aec_bypass_frames = 0;
    for (;;) {
        int ret = esp_codec_dev_read(s_mic, stereo, (int)(2U * mono_bytes));
        if (ret != 0) {
            ESP_LOGW(TAG, "ES7210 read error: %d", ret);
            memset(mic, 0, mono_bytes);
        } else {
            for (int i = 0; i < feed_samples; i++) {
                mic[i] = sat16((int32_t)stereo[i * 2] * MIC_SOFT_GAIN);
            }
        }
        const bool have_ref = playback_ref_snapshot(ref);
        /* When DAC is silent, acoustic echo is absent. Do not run an echo
         * canceller on a zero/stale reference: forward microphone PCM intact.
         * This isolates idle recognition from AEC artifacts. */
        if (have_ref) {
            aec_process(aec, mic, ref, clean);
        } else {
            memcpy(clean, mic, mono_bytes);
            ++aec_bypass_frames;
        }
        /* Feed/fetch are independent tasks. If decoder/MultiNet is momentarily
         * slow, do not fill AFE's input ring forever. We still read the next MIC
         * frame on time and drop this AFE frame, keeping realtime audio fresh.
         * Credit returned immediately after each successful fetch(). */
        if (s_afe_feed_credits && xSemaphoreTake(s_afe_feed_credits, 0) == pdTRUE) {
            if (afe->feed(data, clean) < 0) {
                xSemaphoreGive(s_afe_feed_credits);
                ++s_afe_frames_dropped;
            }
        } else {
            ++s_afe_frames_dropped;
        }
        if (++frames % AEC_STATS_INTERVAL == 0U) {
            int mic_peak = 0, ref_peak = 0, clean_peak = 0;
            bool clipped = false;
            for (int i = 0; i < feed_samples; i++) {
                int x = mic[i];
                if (x == INT16_MIN || x == INT16_MAX) {
                    clipped = true;
                }
                if (x < 0) {
                    x = -x;
                }
                if (x > mic_peak) {
                    mic_peak = x;
                }

                x = ref[i];
                if (x < 0) {
                    x = -x;
                }
                if (x > ref_peak) {
                    ref_peak = x;
                }

                x = clean[i];
                if (x < 0) {
                    x = -x;
                }
                if (x > clean_peak) {
                    clean_peak = x;
                }
            }
            if (clipped) ++clipped_frames;
            ESP_LOGI(TAG, "AEC_STATS frames=%lu mic_peak=%d ref_peak=%d clean_peak=%d "
                          "ref_valid=%d playing=%d ref_missing=%lu afe_dropped=%lu afe_fetched=%lu "
                          "aec_bypass=%lu clips_diag=%lu mic_gain=%d",
                     (unsigned long)frames, mic_peak, ref_peak, clean_peak, (int)have_ref,
                     (int)s_player_active, (unsigned long)s_ref_underruns,
                     (unsigned long)s_afe_frames_dropped, (unsigned long)s_afe_frames_fetched,
                     (unsigned long)aec_bypass_frames, (unsigned long)clipped_frames, MIC_SOFT_GAIN);
        }
        /* ES7210 read is the stream pacing source; maintain 16 kHz input. */
    }
}
static void voice_detect_task(void *arg) {
    (void)arg;
    srmodel_list_t *models = esp_srmodel_init("model");
    if (!models) { ESP_LOGE(TAG, "No model partition"); vTaskDelete(NULL); return; }
    char *model_name = esp_srmodel_filter(models, ESP_MN_PREFIX, ESP_MN_ENGLISH);
    if (!model_name) { ESP_LOGE(TAG, "Select mn7_en in menuconfig and flash srmodels.bin"); vTaskDelete(NULL); return; }
    const esp_mn_iface_t *mn = esp_mn_handle_from_name(model_name);
    if (!mn) { ESP_LOGE(TAG, "MultiNet iface missing"); vTaskDelete(NULL); return; }
    model_iface_data_t *mn_data = mn->create(model_name, 6000);
    if (!mn_data) { ESP_LOGE(TAG, "MultiNet create OOM"); vTaskDelete(NULL); return; }
    ESP_ERROR_CHECK(esp_mn_commands_alloc(mn, mn_data));
    ESP_ERROR_CHECK(esp_mn_commands_clear());
    static const struct { int id; const char *word; } commands[] = {
        {CMD_NEXT, "NEXT"}, {CMD_BACK, "BACK"}, {CMD_ENTER, "ENTER"},
        {CMD_EXIT, "EXIT"}, {CMD_STOP, "STOP"}
    };
    for (unsigned i = 0; i < sizeof(commands)/sizeof(commands[0]); ++i) {
        ESP_ERROR_CHECK(esp_mn_commands_add(commands[i].id, commands[i].word));
    }
    esp_mn_error_t *errors = esp_mn_commands_update();
    if (errors) ESP_LOGW(TAG, "MultiNet command update returned errors");
    mn->print_active_speech_commands(mn_data);
    afe_config_t *cfg = afe_config_init("M", models, AFE_TYPE_SR, AFE_MODE_LOW_COST);
    if (!cfg) { ESP_LOGE(TAG, "AFE config failed"); vTaskDelete(NULL); return; }
    const esp_afe_sr_iface_t *afe = esp_afe_handle_from_config(cfg);
    if (!afe) { afe_config_free(cfg); vTaskDelete(NULL); return; }
    esp_afe_sr_data_t *afe_data = afe->create_from_config(cfg);
    afe_config_free(cfg);
    if (!afe_data) { ESP_LOGE(TAG, "AFE init failed"); vTaskDelete(NULL); return; }
    if (afe->get_feed_chunksize(afe_data) != mn->get_samp_chunksize(mn_data) ||
        afe->get_fetch_chunksize(afe_data) != mn->get_samp_chunksize(mn_data)) {
        ESP_LOGE(TAG, "AFE and MultiNet sample frame mismatch"); vTaskDelete(NULL); return;
    }
    /* The fetch pipeline blocks as needed; limit the producer to four frames
     * of lead. No extra delay is inserted after MultiNet detect(). */
    s_afe_feed_credits = xSemaphoreCreateCounting(AFE_MAX_INFLIGHT_FRAMES, AFE_MAX_INFLIGHT_FRAMES);
    if (!s_afe_feed_credits) {
        ESP_LOGE(TAG, "Cannot create AFE flow semaphore"); vTaskDelete(NULL); return;
    }
    ESP_LOGI(TAG, "AFE FLOW CONTROL: max_inflight=%u, fetch=priority7, no fixed 1-tick delay",
             (unsigned)AFE_MAX_INFLIGHT_FRAMES);
    void **feed_args = malloc(sizeof(void *) * 2);
    if (!feed_args) { ESP_LOGE(TAG, "AFE feed args OOM"); vTaskDelete(NULL); return; }
    feed_args[0] = (void *)afe; feed_args[1] = afe_data;
    if (xTaskCreatePinnedToCore(voice_feed_task, "svx_mic_feed", 8192, feed_args, 6, NULL, 0) != pdPASS) {
        ESP_LOGE(TAG, "Cannot create MIC feed task"); free(feed_args); vTaskDelete(NULL); return;
    }
    ESP_LOGI(TAG, "Offline speech: %s; five commands active; C8.21 FD AEC before AFE", model_name);
    ESP_LOGW(TAG, "STOP sensitivity: threshold=%.2f playing, VAD min=%u frames; rearm=%u frames; single STOP; echo false-positive risk",
             (double)MIN_SCORE_STOP_PLAYING, (unsigned)STOP_MIN_VAD_FRAMES,
             (unsigned)VAD_MAX_UTTERANCE_FRAMES);
    s_voice_ready = true;
    bool have_speech = false;
    bool delivered_in_utterance = false;
    uint32_t speech_frames_in_utterance = 0;
    uint32_t utterance_total_frames = 0;
    uint32_t forced_rearms = 0;
    uint32_t silence_frames = VAD_END_SILENCE_FRAMES;
    uint32_t frame_id = 0, last_speech_frame = 0;
    TickType_t last_command_at = xTaskGetTickCount() - pdMS_TO_TICKS(COMMAND_COOLDOWN_MS);
    ESP_LOGW(TAG, "v35: single STOP acts immediately; NEXT/BACK auto-play; idle NAV threshold=%.2f; music echo can trigger false positives",
             (double)MIN_SCORE_IDLE_NAV);
    for (;;) {
        afe_fetch_result_t *r = afe->fetch(afe_data);
        if (!r || r->ret_value == ESP_FAIL || !r->data) {
            ESP_LOGE(TAG, "AFE fetch failed"); vTaskDelay(pdMS_TO_TICKS(30)); continue;
        }
        /* Release room for one new live MIC frame BEFORE running MultiNet.
         * This avoids AFE feeding unchecked while inference takes time. */
        s_afe_frames_fetched++;
        if (s_afe_feed_credits) xSemaphoreGive(s_afe_feed_credits);
        bool speech = r->vad_state == VAD_SPEECH;
        if (speech) { last_speech_frame = frame_id; have_speech = true; }
        s_reduce_playback = speech;
        /* Short VAD gaps do not split an utterance. A new utterance only
         * begins after >=384ms of real silence. This prevents the speech
         * duration from accumulating across unrelated phrases and makes
         * delivered_in_utterance a real per-utterance latch. */
        /* Real loudspeaker echo or noisy VAD can remain in SPEECH for tens of
         * seconds. Without a maximum length, delivered_in_utterance stays true
         * forever after the first command, and all later STOPs are discarded.
         * Bound each VAD command window to 96 fetched frames (3.072 seconds),
         * even when there is no 384ms silence. Keep the independent command
         * cooldown so repeated recognitions cannot trigger commands rapidly.
         * The re-arm only resets the command state machine. */
        if (speech) {
            if (silence_frames >= VAD_END_SILENCE_FRAMES ||
                utterance_total_frames >= VAD_MAX_UTTERANCE_FRAMES) {
                if (utterance_total_frames >= VAD_MAX_UTTERANCE_FRAMES) {
                    ++forced_rearms;
                    ESP_LOGW(TAG, "VOICE FORCE REARM: continuous VAD for %lu frames; "
                                  "previous_delivered=%d total_rearms=%lu",
                             (unsigned long)utterance_total_frames,
                             (int)delivered_in_utterance, (unsigned long)forced_rearms);
                } else {
                    ESP_LOGI(TAG, "VOICE speech started (new utterance)");
                }
                delivered_in_utterance = false;
                speech_frames_in_utterance = 0;
                utterance_total_frames = 0;
            }
            silence_frames = 0;
            ++speech_frames_in_utterance;
            ++utterance_total_frames;
        } else {
            if (silence_frames < VAD_END_SILENCE_FRAMES) {
                ++silence_frames;
                ++utterance_total_frames;
                if (silence_frames == VAD_END_SILENCE_FRAMES) {
                    ESP_LOGI(TAG, "VOICE speech ended (utterance closed)");
                    have_speech = false;
                    utterance_total_frames = 0;
                }
            }
        }
        esp_mn_state_t state = mn->detect(mn_data, r->data);
        if (state == ESP_MN_STATE_DETECTED) {
            esp_mn_results_t *res = mn->get_results(mn_data);
            if (res && res->num > 0) {
                int id = res->command_id[0]; float score = res->prob[0];
                bool vad_ok = have_speech && (speech ||
                    (frame_id >= last_speech_frame && frame_id - last_speech_frame <= 8U));
                bool valid_id = id >= CMD_NEXT && id <= CMD_STOP;
                bool time_ok = (xTaskGetTickCount() - last_command_at) >= pdMS_TO_TICKS(COMMAND_COOLDOWN_MS);
                float threshold = s_player_active
                    ? (id == CMD_STOP ? MIN_SCORE_STOP_PLAYING : MIN_SCORE_PLAYING)
                    : ((id == CMD_NEXT || id == CMD_BACK) ? MIN_SCORE_IDLE_NAV : MIN_SCORE_IDLE);
                bool stop_duration_ok = id != CMD_STOP || !s_player_active ||
                    speech_frames_in_utterance >= STOP_MIN_VAD_FRAMES;
                bool base_accept = valid_id && vad_ok && score >= threshold &&
                    stop_duration_ok && !delivered_in_utterance && time_ok;
                const char *reason = base_accept ? "base-accepted" :
                    !valid_id ? "bad-id" :
                    !vad_ok ? "no-VAD" :
                    score < threshold ? "low-score" :
                    !stop_duration_ok ? "short-STOP-utterance" :
                    delivered_in_utterance ? "already-delivered-in-utterance" :
                    !time_ok ? "cooldown" : "unknown";
                /* One valid STOP must immediately enter the player command queue.
                 * Do not require a second utterance: playback echo can hold VAD
                 * active and make that confirmation impossible. Keep the per-
                 * utterance latch and cooldown to avoid repeated commands. */
                bool execute = base_accept;
                ESP_LOGI(TAG, "VOICE %s name=%s id=%d score=%.3f threshold=%.2f playing=%d vad=%d speech_frames=%lu stop_vad_ok=%d reason=%s",
                         execute ? "COMMAND" : "REJECT", cmd_name(id), id, (double)score,
                         (double)threshold, (int)s_player_active, (int)speech,
                         (unsigned long)speech_frames_in_utterance, (int)stop_duration_ok, reason);
                if (execute) {
                    voice_cmd_t cmd = (voice_cmd_t)id;
                    if (xQueueSend(s_commands, &cmd, 0) == pdTRUE) {
                        last_command_at = xTaskGetTickCount();
                        delivered_in_utterance = true;
                        ESP_LOGI(TAG, "PLAYER COMMAND QUEUED: %s", cmd_name(cmd));
                    } else {
                        ESP_LOGE(TAG, "PLAYER COMMAND QUEUE FULL: %s", cmd_name(cmd));
                    }
                }
            }
            mn->clean(mn_data);
        } else if (state == ESP_MN_STATE_TIMEOUT) {
            mn->clean(mn_data);
        }
        frame_id++;
        /* DO NOT sleep one RTOS tick per 32ms frame. This was a measurable
         * source of AFE producer/consumer imbalance in v25. fetch() already
         * blocks when no output is available. */
    }
}

typedef struct {
    uint32_t input_rate;
    uint64_t source_index;
    uint64_t next_out_scaled;
    int16_t prior;
    bool have_prior;
    size_t buffered;
} resampler_t;
/* Continuous linear interpolation: output phase is in units of output frames.
 * Source coordinate of each sample k is k * 16000; target output coordinate
 * n * input_rate. This avoids resetting resample phase between decode chunks. */
static bool flush_pcm(resampler_t *rs) {
    if (!rs->buffered) return true;
    /* Submit the same final resampled PCM to the reference just before
     * submitting it to ES8311; the codec call may block for DMA pacing. */
    playback_ref_push(s_pcm16_out, rs->buffered);
    bool ok = esp_codec_dev_write(s_dac, s_pcm16_out, rs->buffered * 2U * sizeof(int16_t)) == 0;
    if (!ok) playback_ref_clear();
    rs->buffered = 0;
    return ok;
}
static bool resample_and_play(resampler_t *rs, const uint8_t *data, size_t bytes, int channels) {
    if (channels != 1 && channels != 2) return false;
    const int16_t *pcm = (const int16_t *)data;
    size_t frames = bytes / (sizeof(int16_t) * (size_t)channels);
    for (size_t i = 0; i < frames; ++i) {
        int32_t cur = channels == 1 ? pcm[i] : ((int32_t)pcm[i * 2U] + pcm[i * 2U + 1U]) / 2;
        uint64_t k = rs->source_index++;
        if (!rs->have_prior) { rs->prior = (int16_t)cur; rs->have_prior = true; }
        uint64_t end = k * FREQ_HZ;
        uint64_t start = k == 0 ? 0 : (k - 1U) * FREQ_HZ;
        while (rs->next_out_scaled <= end) {
            uint64_t pos = rs->next_out_scaled - start;
            if (pos > FREQ_HZ) pos = FREQ_HZ;
            int32_t sample = (int32_t)rs->prior +
                ((cur - (int32_t)rs->prior) * (int32_t)pos) / (int32_t)FREQ_HZ;
            /* No VAD-triggered ducking: rapid VAD toggling while music plays
             * would cause amplitude pumping. */
            int16_t out = sat16(sample);
            s_pcm16_out[rs->buffered * 2U] = out;
            s_pcm16_out[rs->buffered * 2U + 1U] = out;
            rs->buffered++;
            if (rs->buffered >= OUTPUT_FRAMES && !flush_pcm(rs)) return false;
            rs->next_out_scaled += rs->input_rate;
        }
        rs->prior = (int16_t)cur;
    }
    return true;
}
static void set_dac_mute(bool mute) {
    if (!s_dac || s_dac_muted == mute) return;
    int ret = esp_codec_dev_set_out_mute(s_dac, mute);
    if (ret == 0) {
        s_dac_muted = mute;
        if (mute) playback_ref_clear();
        ESP_LOGI(TAG, "DAC %s (volume=%d)", mute ? "MUTED" : "UNMUTED", SPEAKER_VOLUME);
    } else {
        ESP_LOGE(TAG, "DAC mute=%d failed code=%d", mute, ret);
    }
}
static bool poll_command(voice_cmd_t *out) {
    return xQueueReceive(s_commands, out, 0) == pdTRUE;
}
static play_result_t play_file(const char *path) {
    FILE *fp = fopen(path, "rb");
    if (!fp) { ESP_LOGE(TAG, "MP3 open failed: %s errno=%d", path, errno); return PLAY_ERROR; }
    esp_audio_simple_dec_cfg_t cfg = {.dec_type = ESP_AUDIO_SIMPLE_DEC_TYPE_MP3, .use_frame_dec = false};
    esp_audio_simple_dec_handle_t decoder = NULL;
    if (esp_audio_simple_dec_open(&cfg, &decoder) != ESP_AUDIO_ERR_OK || !decoder) {
        fclose(fp); return PLAY_ERROR;
    }
    set_dac_mute(false);
    s_player_active = true;
    ESP_LOGI(TAG, "PLAY: %s", path);
    resampler_t rs = {0};
    play_result_t outcome = PLAY_END;
    bool got_pcm = false;
    unsigned stagnant = 0;
    for (;;) {
        voice_cmd_t cmd;
        if (poll_command(&cmd)) {
            if (cmd == CMD_NEXT) { outcome = PLAY_NEXT; break; }
            if (cmd == CMD_BACK) { outcome = PLAY_BACK; break; }
            if (cmd == CMD_EXIT) { outcome = PLAY_EXIT; break; }
            if (cmd == CMD_STOP) { outcome = PLAY_STOP; break; }
            /* ENTER during playback does nothing */
        }
        size_t n = fread(s_mp3_bytes, 1, sizeof(s_mp3_bytes), fp);
        bool eof = n < sizeof(s_mp3_bytes);
        if (ferror(fp)) { outcome = PLAY_ERROR; break; }
        esp_audio_simple_dec_raw_t raw = {.buffer = s_mp3_bytes, .len = (uint32_t)n, .eos = eof};
        unsigned it = 0;
        do {
            if (++it > 4096) { outcome = PLAY_ERROR; break; }
            esp_audio_simple_dec_out_t out = {.buffer = s_decoded, .len = sizeof(s_decoded)};
            esp_audio_err_t er = esp_audio_simple_dec_process(decoder, &raw, &out);
            if (er != ESP_AUDIO_ERR_OK) { ESP_LOGE(TAG, "Decoder error %d", (int)er); outcome = PLAY_ERROR; break; }
            if (out.decoded_size) {
                esp_audio_simple_dec_info_t info = {0};
                if (esp_audio_simple_dec_get_info(decoder, &info) != ESP_AUDIO_ERR_OK ||
                    info.bits_per_sample != 16 || (info.channel != 1 && info.channel != 2) ||
                    info.sample_rate < 8000 || info.sample_rate > 48000) {
                    ESP_LOGE(TAG, "Unsupported MP3 format"); outcome = PLAY_ERROR; break;
                }
                if (rs.input_rate == 0) {
                    rs.input_rate = info.sample_rate;
                    ESP_LOGI(TAG, "MP3 source %lu Hz %u-ch -> I2S 16000Hz stereo16",
                             (unsigned long)rs.input_rate, (unsigned)info.channel);
                }
                if (rs.input_rate != info.sample_rate ||
                    !resample_and_play(&rs, out.buffer, out.decoded_size, info.channel)) {
                    outcome = PLAY_ERROR; break;
                }
                got_pcm = true;
            }
            if (raw.consumed > raw.len) { outcome = PLAY_ERROR; break; }
            if (raw.consumed == 0 && out.decoded_size == 0) {
                if (++stagnant > 3) { outcome = PLAY_ERROR; break; }
            } else stagnant = 0;
            raw.buffer += raw.consumed; raw.len -= raw.consumed;
        } while (raw.len > 0 && outcome != PLAY_ERROR);
        if (outcome == PLAY_ERROR || eof) break;
    }
    if (outcome == PLAY_END && !flush_pcm(&rs)) outcome = PLAY_ERROR;
    esp_audio_simple_dec_close(decoder);
    fclose(fp);
    if (outcome == PLAY_END && !got_pcm) outcome = PLAY_ERROR;
    s_player_active = false;
    set_dac_mute(true); /* Never leave the speaker active during STOP/idle. */
    ESP_LOGI(TAG, "TRACK DONE status=%d path=%s", outcome, path);
    return outcome;
}
static void player_task(void *arg) {
    (void)arg;
    esp_audio_err_t rc = esp_audio_dec_register_default();
    if (rc != ESP_AUDIO_ERR_OK) { ESP_LOGE(TAG, "Core MP3 decoder init %d", (int)rc); vTaskDelete(NULL); return; }
    rc = esp_audio_simple_dec_register_default();
    if (rc != ESP_AUDIO_ERR_OK) { ESP_LOGE(TAG, "Simple MP3 decoder init %d", (int)rc); vTaskDelete(NULL); return; }
    if (esp_audio_simple_check_audio_type(ESP_AUDIO_SIMPLE_DEC_TYPE_MP3) != ESP_AUDIO_ERR_OK) {
        ESP_LOGE(TAG, "MP3 backend unavailable"); vTaskDelete(NULL); return;
    }
    ESP_LOGI(TAG, "MP3 ready: %u tracks; voice=%s. Say ENTER to start, NEXT/BACK to navigate",
             (unsigned)s_track_count, s_voice_ready ? "READY" : "INITIALIZING");
    size_t index = 0;
    bool playing = true; /* Auto-start. NEXT/BACK always navigate and play; ENTER resumes. */
    bool halted = false;
    for (;;) {
        if (!s_track_count) { vTaskDelay(pdMS_TO_TICKS(3000)); continue; }
        if (!playing) {
            voice_cmd_t c;
            if (xQueueReceive(s_commands, &c, pdMS_TO_TICKS(200)) != pdTRUE) continue;
            if (c == CMD_ENTER) { playing = true; halted = false; }
            else if (c == CMD_NEXT) {
                index = (index + 1U) % s_track_count;
                playing = true;
                halted = false;
                ESP_LOGI(TAG, "NEXT while idle: select and PLAY immediately");
            }
            else if (c == CMD_BACK) {
                index = (index + s_track_count - 1U) % s_track_count;
                playing = true;
                halted = false;
                ESP_LOGI(TAG, "BACK while idle: select and PLAY immediately");
            }
            else if (c == CMD_EXIT) { halted = true; index = 0; }
            else if (c == CMD_STOP) { halted = false; }
            /* NEXT/BACK must always play selected track. ENTER resumes current selection. */
            ESP_LOGI(TAG, "PLAYER %s track=%u action=%s", halted ? "HALTED" : (playing ? "PLAY" : "IDLE"),
                     (unsigned)(index + 1U), cmd_name(c));
            continue;
        }
        play_result_t r = play_file(s_tracks[index]);
        if (r == PLAY_NEXT) index = (index + 1U) % s_track_count;
        else if (r == PLAY_BACK) index = (index + s_track_count - 1U) % s_track_count;
        else if (r == PLAY_STOP) playing = false;
        else if (r == PLAY_EXIT) { playing = false; index = 0; }
        else index = (index + 1U) % s_track_count;
        vTaskDelay(pdMS_TO_TICKS(40));
    }
}
/* Test the MP3 hardware independently of recognition via USB COM10.
 * N=next, B=back, P=play/resume, S=stop, X=exit/reset playlist. */
static void console_task(void *arg) {
    (void)arg;
    ESP_LOGI(TAG, "COM10 shortcuts: N NEXT, B BACK, P PLAY, S STOP, X EXIT (then Enter)");
    for (;;) {
        int ch = getchar();
        if (ch == EOF) { clearerr(stdin); vTaskDelay(pdMS_TO_TICKS(100)); continue; }
        voice_cmd_t cmd;
        switch (ch) {
            case 'n': case 'N': cmd = CMD_NEXT; break;
            case 'b': case 'B': cmd = CMD_BACK; break;
            case 'p': case 'P': cmd = CMD_ENTER; break;
            case 's': case 'S': cmd = CMD_STOP; break;
            case 'x': case 'X': cmd = CMD_EXIT; break;
            default: continue;
        }
        if (xQueueSend(s_commands, &cmd, 0) == pdTRUE)
            ESP_LOGI(TAG, "SERIAL command=%s", cmd_name(cmd));
    }
}
void app_main(void) {
    ESP_LOGI(TAG, "SaturnVex voice-controlled SD MP3 — v35 Single STOP / MIC4x / AEC idle bypass");
    ESP_LOGW(TAG, "v35: STOP once = mute; NEXT/BACK once = auto-play; volume=85; music echo may falsely trigger STOP");
    ESP_LOGW(TAG, "AEC is enabled but playback/mic delay is approximate; calibrate echo alignment before production");
    s_commands = xQueueCreate(12, sizeof(voice_cmd_t));
    s_tracks = heap_caps_calloc(MAX_TRACKS, sizeof(char *), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!s_commands || !s_tracks) { ESP_LOGE(TAG, "Out of memory for playlist/commands"); return; }
    if (mount_sd() != ESP_OK || init_audio() != ESP_OK) {
        ESP_LOGE(TAG, "SD or ES7210/ES8311 initialization failed"); return;
    }
    scan_tree(SD_MOUNT, 0);
    ESP_LOGI(TAG, "Recursive playlist: %u MP3 files", (unsigned)s_track_count);
    if (xTaskCreatePinnedToCore(voice_detect_task, "svx_voice", 16384, NULL, 7, NULL, 1) != pdPASS)
        ESP_LOGE(TAG, "Voice task create failed");
    if (xTaskCreatePinnedToCore(player_task, "svx_player", 16384, NULL, 4, NULL, 0) != pdPASS)
        ESP_LOGE(TAG, "Player task create failed");
    if (xTaskCreatePinnedToCore(console_task, "svx_cli", 4096, NULL, 2, NULL, 0) != pdPASS)
        ESP_LOGW(TAG, "Serial shortcut task not created");
}
