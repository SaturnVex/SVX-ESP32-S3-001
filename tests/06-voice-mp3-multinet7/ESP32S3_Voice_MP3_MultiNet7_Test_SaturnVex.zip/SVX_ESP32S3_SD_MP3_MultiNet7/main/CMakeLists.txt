idf_component_register(
    SRCS "main.c"
    INCLUDE_DIRS "."
    REQUIRES
        esp_driver_i2c
        esp_driver_i2s
        esp_driver_sdmmc
        fatfs
        sdmmc
        espressif__esp_codec_dev
        espressif__esp_audio_codec
        espressif__esp-sr
)
