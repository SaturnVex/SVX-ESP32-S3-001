/*
 * SaturnVex  |  www.saturnvex.com  |  support@saturnvex.com
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * SPDX-License-Identifier: BSD-3-Clause  (see LICENSE.txt)
 *
 * Project : SVX_ESP32S3_SD_Card_Test
 * File    : main/main.c
 * Board   : SVX-ESP32-S3-001 (ESP32-S3), ESP-IDF v6.1
 * Purpose : microSD read/write verification over SDMMC 1-bit (CLK GPIO17, CMD GPIO8,
 *           D0 GPIO18): 4096-byte binary write/readback and 10 appended CSV records.
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <errno.h>
#include <sys/stat.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_vfs_fat.h"
#include "driver/sdmmc_host.h"
#include "sdmmc_cmd.h"

#define TAG "SVX_SD"
#define MOUNT_POINT "/sdcard"
#define LOG_FILE MOUNT_POINT "/svx_log.csv"
#define TEST_FILE MOUNT_POINT "/svx_test.bin"
#define SD_GPIO_CLK GPIO_NUM_17
#define SD_GPIO_CMD GPIO_NUM_8
#define SD_GPIO_D0  GPIO_NUM_18
#define TEST_SIZE 4096U
#define LOG_PERIOD_MS 5000U

static uint8_t pattern_byte(size_t i) { return (uint8_t)((i * 37U + (i >> 3U) + 0x5AU) & 0xFFU); }

static esp_err_t binary_write_and_verify(void)
{
    uint8_t data[256];
    FILE *fp = fopen(TEST_FILE, "wb");
    if (!fp) { ESP_LOGE(TAG, "Open write failed %s: errno=%d", TEST_FILE, errno); return ESP_FAIL; }
    for (size_t offset = 0; offset < TEST_SIZE; offset += sizeof(data)) {
        for (size_t i = 0; i < sizeof(data); ++i) data[i] = pattern_byte(offset + i);
        if (fwrite(data, 1, sizeof(data), fp) != sizeof(data)) {
            ESP_LOGE(TAG, "Binary write error at offset %u", (unsigned)offset);
            fclose(fp); return ESP_FAIL;
        }
    }
    if (fflush(fp) != 0) { ESP_LOGE(TAG, "Binary flush error"); fclose(fp); return ESP_FAIL; }
    if (fclose(fp) != 0) { ESP_LOGE(TAG, "Binary close error"); return ESP_FAIL; }
    fp = fopen(TEST_FILE, "rb");
    if (!fp) { ESP_LOGE(TAG, "Binary reopen failed: errno=%d", errno); return ESP_FAIL; }
    for (size_t offset = 0; offset < TEST_SIZE; offset += sizeof(data)) {
        if (fread(data, 1, sizeof(data), fp) != sizeof(data)) {
            ESP_LOGE(TAG, "Binary read error at offset %u", (unsigned)offset);
            fclose(fp); return ESP_FAIL;
        }
        for (size_t i = 0; i < sizeof(data); ++i) {
            if (data[i] != pattern_byte(offset + i)) {
                ESP_LOGE(TAG, "MISMATCH at byte %u: got=0x%02x expected=0x%02x",
                         (unsigned)(offset + i), data[i], pattern_byte(offset + i));
                fclose(fp); return ESP_FAIL;
            }
        }
    }
    const int extra = fgetc(fp);
    if (fclose(fp) != 0 || extra != EOF) { ESP_LOGE(TAG, "Binary file size mismatch/close error"); return ESP_FAIL; }
    ESP_LOGI(TAG, "PASS binary write + readback: %u bytes verified byte-for-byte", TEST_SIZE);
    return ESP_OK;
}

static esp_err_t append_log_and_verify(uint32_t sample)
{
    char entry[96];
    const int64_t uptime_ms = esp_timer_get_time() / 1000;
    const int n = snprintf(entry, sizeof(entry), "%" PRIu32 ",%" PRId64 ",PASS\n", sample, uptime_ms);
    if (n < 0 || (size_t)n >= sizeof(entry)) return ESP_FAIL;
    FILE *fp = fopen(LOG_FILE, "ab");
    if (!fp) { ESP_LOGE(TAG, "CSV open append failed: errno=%d", errno); return ESP_FAIL; }
    if (fwrite(entry, 1, (size_t)n, fp) != (size_t)n || fflush(fp) != 0) {
        ESP_LOGE(TAG, "CSV append/flush failed: errno=%d", errno);
        fclose(fp); return ESP_FAIL;
    }
    if (fclose(fp) != 0) { ESP_LOGE(TAG, "CSV close failed"); return ESP_FAIL; }
    // Verify exact last record (the file may retain earlier test runs).
    fp = fopen(LOG_FILE, "rb");
    if (!fp) return ESP_FAIL;
    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); return ESP_FAIL; }
    long size = ftell(fp);
    if (size < n || fseek(fp, size - n, SEEK_SET) != 0) { fclose(fp); return ESP_FAIL; }
    char readback[96] = {0};
    size_t got = fread(readback, 1, (size_t)n, fp);
    fclose(fp);
    if (got != (size_t)n || memcmp(readback, entry, (size_t)n) != 0) {
        ESP_LOGE(TAG, "CSV tail verification FAILED"); return ESP_FAIL;
    }
    ESP_LOGI(TAG, "PASS CSV append/readback: %s", entry);
    return ESP_OK;
}

void app_main(void)
{
    ESP_LOGI(TAG, "SaturnVex SDMMC Test | SVX-ESP32-S3-001");
    ESP_LOGI(TAG, "SDMMC 1-bit: CLK=GPIO17, CMD=GPIO8, D0=GPIO18");
    ESP_LOGW(TAG, "This test overwrites /sdcard/svx_test.bin and appends /sdcard/svx_log.csv");
    sdmmc_host_t host = SDMMC_HOST_DEFAULT();
    host.slot = SDMMC_HOST_SLOT_1;
    host.max_freq_khz = 10000; // Conservative 10 MHz bring-up, not maximum speed.

    sdmmc_slot_config_t slot = SDMMC_SLOT_CONFIG_DEFAULT();
    slot.width = 1;
    slot.clk = SD_GPIO_CLK;
    slot.cmd = SD_GPIO_CMD;
    slot.d0 = SD_GPIO_D0;
    slot.flags |= SDMMC_SLOT_FLAG_INTERNAL_PULLUP;
    // DAT1-DAT3 are not driven in 1-bit mode. Board provides external pullups.

    esp_vfs_fat_sdmmc_mount_config_t mount = {
        .format_if_mount_failed = false, // Never erase/format a user SD card.
        .max_files = 5,
        .allocation_unit_size = 16 * 1024,
    };
    sdmmc_card_t *card = NULL;
    esp_err_t err = esp_vfs_fat_sdmmc_mount(MOUNT_POINT, &host, &slot, &mount, &card);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "SD mount FAILED: %s (0x%x)", esp_err_to_name(err), (unsigned)err);
        ESP_LOGE(TAG, "Check card seating, FAT32 format, 3.3V, pullups and SD wiring. No formatting performed.");
        while (true) vTaskDelay(pdMS_TO_TICKS(5000));
    }
    ESP_LOGI(TAG, "SD card mounted: %s", MOUNT_POINT);
    sdmmc_card_print_info(stdout, card);
    if (binary_write_and_verify() != ESP_OK) {
        ESP_LOGE(TAG, "Initial binary verification failed. Stopping writes.");
        esp_vfs_fat_sdcard_unmount(MOUNT_POINT, card);
        while (true) vTaskDelay(pdMS_TO_TICKS(5000));
    }

    // Preserve existing log file. Create header only for an empty or new file.
    struct stat st;
    if (stat(LOG_FILE, &st) != 0 || st.st_size == 0) {
        FILE *f = fopen(LOG_FILE, "ab");
        if (!f) { ESP_LOGE(TAG, "Cannot create CSV log: errno=%d", errno); goto unmount; }
        static const char header[] = "seq,uptime_ms,status\n";
        if (fwrite(header, 1, sizeof(header) - 1, f) != sizeof(header) - 1 || fflush(f) != 0) {
            ESP_LOGE(TAG, "Cannot write CSV header"); fclose(f); goto unmount;
        }
        if (fclose(f) != 0) { ESP_LOGE(TAG, "Cannot close CSV header"); goto unmount; }
    }

    for (uint32_t sample = 1; sample <= 10; ++sample) {
        if (append_log_and_verify(sample) != ESP_OK) {
            ESP_LOGE(TAG, "Test FAILED at record %" PRIu32, sample);
            goto unmount;
        }
        vTaskDelay(pdMS_TO_TICKS(LOG_PERIOD_MS));
    }
    ESP_LOGI(TAG, "SUCCESS: 4096-byte binary test and 10 CSV records verified.");
    ESP_LOGI(TAG, "Files: %s , %s", TEST_FILE, LOG_FILE);

unmount:
    ESP_LOGI(TAG, "Unmount SD safely");
    esp_err_t unmount_err = esp_vfs_fat_sdcard_unmount(MOUNT_POINT, card);
    if (unmount_err != ESP_OK) ESP_LOGE(TAG, "Unmount failed: %s", esp_err_to_name(unmount_err));
    ESP_LOGI(TAG, "Test complete. Firmware idle; press RESET to repeat.");
    while (true) vTaskDelay(pdMS_TO_TICKS(5000));
}
