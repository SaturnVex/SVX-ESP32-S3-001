# microSD Card Read / Write Test

**Project:** `SVX_ESP32S3_SD_Card_Test` · **Board:** `SVX-ESP32-S3-001` · **MCU:** ESP32-S3 · **Framework:** ESP-IDF v6.1

Verifies microSD read and write operations using the ESP32-S3 SDMMC controller in 1-bit mode with the ESP-IDF FAT filesystem. Only drivers included in ESP-IDF are used.

## Connections

| Signal | ESP32-S3 | Notes |
|---|---|---|
| SD CLK | GPIO17 | SDMMC clock, 10 MHz |
| SD CMD | GPIO8 | SDMMC command |
| SD DAT0 | GPIO18 | 1-bit data |
| SD DAT1 – DAT3 | — | Not used by the MCU (board pull-ups) |

## Test sequence

1. Mount the card at `/sdcard` (the card is never formatted).
2. Write a deterministic 4096-byte pattern to `svx_test.bin`, read it back and compare every byte.
3. Append 10 records to `svx_log.csv` at 5-second intervals and read back each appended line.
4. Print `SUCCESS`, unmount the card and idle. Press RESET to repeat.

`svx_test.bin` is overwritten on every run; `svx_log.csv` is appended. Use a FAT32 card and back up its contents first.

## Build and flash

Open this folder (the one containing `CMakeLists.txt`) in VS Code with the ESP-IDF extension, then open an **ESP-IDF v6.1 terminal** and run:

```powershell
Remove-Item Env:IDF_TARGET -ErrorAction SilentlyContinue
idf.py set-target esp32s3
idf.py build
idf.py -p COM_PORT -b 115200 flash monitor
```

Replace `COM_PORT` with the native USB Serial/JTAG port of the board (for example `COM10`). Exit the monitor with `Ctrl+]`.

## Expected result

The monitor shows `SD card mounted`, `PASS binary write + readback: 4096 bytes verified`, ten `PASS CSV append/readback` lines and the final `SUCCESS` message. Both files are readable on a PC afterwards.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex source and project files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
